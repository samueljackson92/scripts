<?php
session_start();
if (!isset($_COOKIE['logged_in_cms']) or !isset($_SESSION['user']))
{
	header("Location: login.php");
}

require_once("../settings.php");
$settings = ServerSettings::getSettings();

$target_path = $settings['cmsdir'] . "/inkblotter/media/" . $_SESSION['currentdir'];
$target_path = $target_path . basename($_FILES['uploadedfile']['name']); 
?>
<html>
	<head>
    	<title>Inkblotter: CMS</title>
		<link type="text/css" rel="stylesheet" href="../../lib/styling/reset.css" />
		<link type="text/css" rel="stylesheet" href="../../lib/styling/masterstyle.css"  />
        
        <link rel="stylesheet" type="text/css" href="../../jquery-ui/development-bundle/themes/base/jquery.ui.core.css">
        <link rel="stylesheet" type="text/css" href="../../jquery-ui/development-bundle/themes/base/jquery.ui.theme.css">
        <link rel="stylesheet" type="text/css" href="../../jquery-ui/development-bundle/themes/base/jquery.ui.button.css">
        
		<!-- Javascript Imports -->     
        <script type="text/javascript" src="../../jquery-ui/js/jquery-1.4.2.min.js"></script>
        <script type="text/javascript" src="../../jquery-ui/js/jquery-ui-1.8.2.custom.min.js"></script>
        <script type="text/javascript" src="../../jquery-ui/development-bundle/ui/jquery.ui.button.js"></script>
		
		<!-- CSS Imports -->
		<script type="text/javascript">
			$(document).ready(function ()
			{
				$("#return").button({ icons: {primary: 'ui-icon-arrowreturnthick-1-w'}});
				$("#return").click();
			});
		</script>
</head>
	<body>
		<div id="content-wrap">
			<div id="content">
				<div id="intro">
                    <div id="userdata">
						<?php
						if(move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path))
							{
						?>
                    	<p><strong>Your file was successfully uploaded.</strong></p>
						<?php
							} else {
						?>
                    	<p><strong>Oops and error occured when uploading you file!</strong></p>
						<?php
							}
						?>
                    </div>
					<a id="return" href="../../index.php">Return to Editor</a>
				</div><!-- intro -->
			</div>
		</div>
	</body>
</html>