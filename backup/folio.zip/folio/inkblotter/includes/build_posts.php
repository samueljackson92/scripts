<?php
	require_once('access.php');
	require_once('dbconnector.php');
	require_once('pagination.php');
	$db = new Database;
	
	$per_page = 5; 
	if(isset($_POST))
	{
		$page = $_POST['page_count'];
	}
	
	//select correct number of records
	$start = $page * $per_page;
	$query_result = $db->makeQuery("SELECT * FROM cmsarticles ORDER BY ID DESC LIMIT $start, $per_page");

	if (mysql_num_rows($query_result))
	{
		 echo '<table><thead>';
		 echo '<tr><td>#</td><td>Post Name</td><td>Tagline</td><td>Edit</td><td>Delete</td></tr></thead><tbody id="posts_table">';
		 
		//build the table full of records
		while ($row = mysql_fetch_array($query_result))
		{
			  echo '<tr id="' . $row['ID'] . '">';
			  echo '<td>' . $row['ID'] . '</td>';
			  echo '<td>' . $row['title'] . '</td>';
			  echo '<td>' . $row['tagline'] . '</td>';
			  echo '<td><a class="edit_post edit" href="#">Edit</a></td>';
			  echo '<td><a class="delete_post delete" href="#">Delete</a></td>';
			  echo '</tr>';
		}
		
		echo '</tbody></table>';
		
		paginate('posts', $per_page);
	}
	else
	{
		echo "<p>No posts to dsiplay</p>";
	}
	
	$db->closeConnection();
?>