<?php
	require("admin/includes/dbconnector.php");
	require("admin/includes/util.php");
	DBConnector::makeConnection();
	
	$pages = DBConnector::makeQuery("SELECT id, title FROM tabs");

	if (isset($_GET['page']) and is_numeric($_GET['page']))
	{
		$page = (int) $_GET['page'];
	}
	else
	{
		$page = "health";
	}
	$pages = DBConnector::makeQuery("SELECT id, title FROM tabs");
	
	if (is_numeric($page))
	{
		$currentpage = mysql_fetch_array(DBConnector::makeQuery("SELECT * FROM tabs WHERE id=$page"));
	}
	else
	{
		$subpages = DBConnector::makeQuery("SELECT id, title FROM health_tabs");
		if (isset($_GET['subpage']) and is_numeric($_GET['subpage']))
		{
			$subpage = (int) $_GET['subpage'];
		}
		elseif(mysql_num_rows($subpages) > 0)
		{
			$q = mysql_fetch_array($subpages);
			$subpage = $q['id'];
			$subpages = DBConnector::makeQuery("SELECT id, title FROM health_tabs");
		}
		else
		{
			$subpage = 0;
		}
		
		$currentpage = mysql_fetch_array(DBConnector::makeQuery("SELECT * FROM health_tabs WHERE id=$subpage"));
	}
?>
<html>
	<head>
		<?php include("includes/meta.php"); ?>
		<style type="text/css">
			ul {text-align: left;}
			#info p {text-align: justify;}
			#subnavbar {padding: 0px; width: 780px;}
			#subnavbar li a {width: 150px;}
		</style>
	</head>
	<body>
		<div id="container">
			<?php include("includes/header.php"); ?>
			<div id="content">
				<div id="subnav">
					<ul id="subnavbar">
						<li><a class="subtab" <?php if ($page == "health") { ?> id="current" <?php } ?> href="<?php echo $SERVER['PHP_SELF'];  ?>?page=health">Health</a></li>
						<?php 
							if (mysql_num_rows($pages) > 0)
							{
								while ($row = mysql_fetch_array($pages))
								{
						?>
						<li><a class="subtab" <?php if ($row['id'] == $page) { ?> id="current" <?php } ?> href="<?php echo $SERVER['PHP_SELF'];  ?>?page=<?php echo $row['id']; ?>"><?php echo html_entity_decode($row['title']); ?></a></li>					
						<?php
								}
							}
						?>
					</ul>
				</div>
				
				<?php
					if ($page == "health" and mysql_num_rows($subpages) > 0)
					{
				?>
				<div id="healthnav">
					<ul id="healthnavbar">
						<?php 
							if (mysql_num_rows($subpages) > 0)
							{
								while ($row = mysql_fetch_array($subpages))
								{
						?>
						<li><a class="subtab" <?php if ($row['id'] == $subpage) { ?> id="current" <?php } ?> href="<?php echo $SERVER['PHP_SELF'];  ?>?subpage=<?php echo $row['id']; ?>"><?php echo html_entity_decode($row['title']); ?></a></li>					
						<?php
								}
							}
						?>
					</ul>
				</div>
				<?php
					}
				?>
				
				<div id="info">
					<?php
						echo html_entity_decode($currentpage['text']);
					?>
						
				</div>
			</div>
			
			<div id="footer">
			</div>	
		</div>	
	</body>	
</html>
