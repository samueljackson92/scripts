<?php
	require_once("../access.php");
	require_once("../settings.php");
	$settings = ServerSettings::getSettings();
	
	$file = $settings['cmsdir'] . "/inkblotter/logs/failedlogins.txt";
	$fh = fopen($file, 'w') or die("can't open file");
	$s = "\n";
	fwrite($fh, $s);
	fclose($fh);
?>