<?php
require("admin/includes/dbconnector.php");

DBConnector::makeConnection();

$q = DBConnector::makeQuery("SELECT * FROM dogs WHERE type=3 ORDER BY id DESC");

?>

<html>
	<head>
		<?php include("includes/meta.php"); ?>
		<script type="text/javascript" src="js/jquery-1.3.2.js"></script>
		<script type="text/javascript" src="js/jquery.galleriffic.js"></script>
	</head>
	<body>
		<div id="container">
			<?php include("includes/header.php"); ?>
			
			<div id="content">
				<h2>Puppies</h2>				
				<div id="dogs">
					<?php
					$keys = array();
					if (mysql_num_rows($q) > 0)
					{
						while ($dog = mysql_fetch_array($q))
						{
							array_push($keys, $dog['id']);
					?>
					<div class="dog">
						<div class="dog-wrap">
							<div class="gallery content">
								<div class="slideshow-container">
									<div id="slideshow_<?php echo $dog['id']; ?>" class="slideshow"></div>
								</div>
								<div class="caption-container"></div>
							</div>
							
							<div class="dogtext">
								<h3><?php echo $dog['dog_name']; ?></h3>
								<small><b>Birth Date:</b> <?php echo $dog['birthdate']; ?></small><br />
								<small><b>Due to leave:</b> <?php echo $dog['due_leave']; ?></small><br />
								<small><b>Mother's Name:</b> <?php echo $dog['mother_name']; ?></small><br />
								<small><b>Father's Name:</b> <?php  echo $dog['father_name']; ?></small><br />
								<a href="<?php echo "admin/" . $dog['pedigree_folder'] . $dog['pedigree']; ?>">Parent's Pedigree</a>
								<p><?php echo $dog['dog_text'];?></p>
								<?php
									if ($dog['is_sold'] == 1)
									{
								?>
									<h4 class="sold">This litter has been sold.</h4>
								<?php
									}
								?>
							</div>
						</div>

						<div class="mini_gallery">
							<div id="thumbs_<?php echo $dog['id']; ?>" class="thumbs navigation">
								<ul class="thumbs noscript">
								<?php
								$images = DBConnector::makeQuery("SELECT * FROM dog_images WHERE img_set=" . $dog['id']. " ORDER BY series ASC");
								
								while($img = mysql_fetch_array($images))
								{
								?>
									<li>
										<a class="thumb" href="admin/<?php echo $dog['img_folder'] . $img['filename'];?>" title="<?php echo $img['filename'];?>">
											<img height="100" width="100" src="admin/<?php echo $dog['img_folder'] . $img['filename'];?>" alt="<?php echo $img['filename'];?>" />
										</a>
									</li>
								<?php
								}
								?>
								</ul>
							</div>
						</div>
					</div>
						
					<?php
						}
					}
					else
					{
					?>
					<span id="nodogs">We currently have no puppies available.</span>
					<?php
					}
					?>
				</div>
			</div>
			<div id="footer">
			</div>
			<script type="text/javascript">
				// We only want these styles applied when javascript is enabled
				$('div.navigation').css({'width' : '300px', 'float' : 'left'});
				$('div.content').css('display', 'block');

				$(document).ready(function() {				
					// Initialize Minimal Galleriffic Gallery
					
					<?php 
						foreach($keys as $key)
						{
					?>
					$('#thumbs_<?php echo $key; ?>').galleriffic({
						imageContainerSel:      '#slideshow_<?php echo $key; ?>'
					});
					<?php
						}
					?>
				});
			</script>
		</div>
	</body>
		
</html>
