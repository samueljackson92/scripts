<?php
require_once('includes/auth.php');
require_once('includes/posts.php');
if (!Auth::check_auth()) {
	Auth::log_out("login.php");
}

?>
<html>
<head>
	<link href="css/general.css" type="text/css" rel="stylesheet" />
</head>
<body>
	<?php include_once('includes/header.php');?>
	<div id="content">
		<p><a href="add_post.php">Add</a></p>
		<table>
			<thead>
				<tr><th>Title</th><th>Edit</th><th>Delete</th></tr>
			</thead>
			<tbody>
				<?php // database content?>
			</tbody>
		</table>
	</div>
	<?php include_once('includes/footer.php');?>
</body>
</html>