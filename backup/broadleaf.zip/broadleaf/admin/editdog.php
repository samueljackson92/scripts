<?php
	require("includes/access.php");
	require("includes/dbconnector.php");
	require("includes/filemanager.php");
	require("includes/util.php");
	
	DBConnector::makeConnection();
	$sexes = DBConnector::makeQuery("SELECT * FROM sex WHERE id=1 OR id=2");
	$breeds = DBConnector::makeQuery("SELECT * FROM breed");
	$training = DBConnector::makeQuery("SELECT * FROM training WHERE id=2 OR id=3");
	
	if (isset($_POST['id']) and is_numeric($_POST['id']))
	{
		$error = false;
		$imagenames = array();
		
		$dog = mysql_fetch_array(DBConnector::makeQuery("SELECT * FROM dogs WHERE id=" . $_POST['id']));
		
		//get post variables, sanatise and insert into database
		$dname = Util::cleanInput($_POST['dog_name']);
		$dtext = Util::cleanInput($_POST['dog_text']);

		$dsex = $_POST['dog_sex'];
		$dbreed = $_POST['dog_breed'];
		
		$mother_name = Util::cleanInput($_POST['mother_name']);
		$father_name = Util::cleanInput($_POST['father_name']);
		
		$leavedate = $_POST['orderdate'];
		$birthdate = $_POST['birthdate'];
		$sold = $_POST['is_sold'];
		
		if (isset($_POST['dog_training']))
		{
			$dtraining = $_POST['dog_training'];
		}
		else
		{
			$dtraining = 1;
		}
		
		$salt = DBConnector::makeQuery("SELECT salt FROM dogs WHERE id=" . $_POST['id']);
		$salt = $salt['salt'];
		
		//remove old pedigree
		if ($_FILES['dog_pedigree']['name'] != NULL)
		{
			$pedigree = DBConnector::makeQuery("SELECT pedigree FROM dogs WHERE id=" . $_POST['id']);
			$pedigree = mysql_fetch_array($pedigree);
			$pedigree = $pedigree['pedigree'];
			
			$target_path = $dog['pedigree_folder'];
			if (!FileManager::removeFile($target_path . $pedigree))
			{
				$error = true;
			}
			
			//upload new pedigree
			$pedigree = array_shift($_FILES);
			
			if(!$pedigree['error'] == 0)
			{
				$error = true;
			}
			
			if($pedigree['size'] > 1500000)
			{
				$error = true;
			}
			
			while (true)
			{
				if (file_exists($target_path . $pedigree))
				{
					$i++;
					$ext = substr(basename($pedigree), -4);
					$pedigree = $pedigree . "(" . $i . ")" . $ext;
				}
				else
				{
					break;
				}
			}
			
			if (!FileManager::uploadFile($pedigree['name'], $pedigree['tmp_name'], $target_path))
			{
				$error = true;
			}
			else
			{
				DBConnector::makeQuery("UPDATE dogs SET pedigree='" . $pedigree['name'] . "' WHERE id=" . $_POST['id']);
			}
		}
	
		//remove old images
		$images = DBConnector::makeQuery("SELECT series FROM dog_images WHERE img_set=". $_POST['id'] ." ORDER BY series DESC");
		$images = mysql_fetch_array($images);
		$num = $images['series'];
		
		$target_path = $dog['img_folder'];
		for ($i=0; $i <= $num; $i++)
		{
			if (isset($_POST['remove_' . $i]) && $_POST['remove_' . $i] == 'on')
			{
				
				$query = mysql_fetch_array(DBConnector::makeQuery("SELECT filename FROM dog_images WHERE img_set=" . $_POST['id'] . " AND series =" . $i));
				
				if (!FileManager::removeFile($target_path . $query['filename']))
				{
					header("Location: error.php");
				}
				else
				{
					DBConnector::makeQuery("DELETE FROM dog_images WHERE img_set=" . $_POST['id'] . " AND series=" . $i);
				}
			}
		}
		
		//upload new images to the server
		$target_path = $dog['img_folder'];
		$images = DBConnector::makeQuery("SELECT series FROM dog_images WHERE img_set=". $_POST['id'] ." ORDER BY series DESC");
		$images = mysql_fetch_array($images);
		$offset = $images['series'] + 1;
		for ($i = 0; $i < count($_FILES['new_images']); $i++)
		{
		
			if ($_FILES['new_images']['name'][$i] != "")
			{
				if($_FILES['new_images']['error'][$i] != 0 and $_FILES['new_images']['error'][$i] != 4)
				{
					$error = true;
				}
				
				if($_FILES['new_images']['size'][$i] > 1500000)
				{
					$error = true;
				}
				
				$fname = $_FILES['new_images']['name'][$i];
				$tmp_name = $_FILES['new_images']['tmp_name'][$i];
				
				while (true)
				{
					if (file_exists($target_path . $fname))
					{
						$j++;
						$ext = substr(basename($fname), -4);
						$fname = $fname . "(" . $j . ")" . $ext;
					}
					else
					{
						break;
					}
				}
				
				if (!FileManager::uploadFile($fname, $tmp_name, $target_path))
				{
					$error = true;
				}
				else
				{
					$key = $offset + $i;
					$id = $_POST['id'];
					DBConnector::makeQuery("INSERT INTO dog_images (id, filename, img_set, series) VALUES ('NULL', '$fname', '$id', '$key')");
				}
			}
		}
		
		if (!$error)
		{
			DBConnector::makeQuery("UPDATE dogs SET dog_name='$dname', dog_text='$dtext', sex='$dsex', breed='$dbreed', training='$dtraining', mother_name='$mother_name', father_name='$father_name', birthdate='$birthdate', due_leave='$leavedate', is_sold='$sold' WHERE id=" . $_POST['id']);
			header("Location: dogs.php?type=" . $_POST['type'] . "&success=0");
		}
	}
	
	
	if (isset($_GET['type']) and is_numeric($_GET['type']))
	{
		$type = (int) $_GET['type'];
	}
	elseif (isset($_POST['type']) and is_numeric($_POST['type']))
	{
		$type = (int) $_POST['type'];
	}
	else
	{
		header("Location: dogs.php?type=1");
		exit;
	}
	
	if (isset($_GET['id']) and is_numeric($_GET['id']))
	{
		$id = (int) $_GET['id'];
		$dog = mysql_fetch_array(DBConnector::makeQuery("SELECT * FROM dogs WHERE id=$id"));
	}
	elseif (isset($_POST['id']) and is_numeric($_POST['id']))
	{	
		$id = (int) $_POST['id'];
		$dog = mysql_fetch_array(DBConnector::makeQuery("SELECT * FROM dogs WHERE id=$id"));
	}
?>

<html>
	<head>
		<script type="text/javascript" src="js/jquery.js"></script>
		<script src="js/jquery.MultiFile.js" type="text/javascript" language="javascript"></script>
		<script type="text/javascript" src="js/calender/calendarDateInput.js" language="javascript">
			/***********************************************
			* Jason's Date Input Calendar- By Jason Moon http://calendar.moonscript.com/dateinput.cfm
			* Script featured on and available at http://www.dynamicdrive.com
			* Keep this notice intact for use.
			***********************************************/
		</script>
		<link rel="stylesheet" type="text/css" href="css/admin-main.css">
		<link rel="stylesheet" type="text/css" href="css/admin-form.css">
		<title>Broadleaf Admin: Edit Dog</title>
		<script type="text/javascript">
			$(document).ready(function ()
			{
				$("#editdog_submit").click(function()
				{
					var flag = false;
					$("#error_output").html("");
					
					if ($("#dog_name").val() == "")
					{
						flag = true;
						$("#error_output").append("<span>You must enter a name for the dog.</span><br />");
					}
					
					if ($("#dog_text").val() == "")
					{
						flag = true;
						$("#error_output").append("<span>You must enter a description for the dog.</span>");
					}
					
					<?php
					if ($type == 3)
					{
					?>
					
					var dateObj = new Date();
					if ($("#orderdate_Year_ID").val().length < 4)
					{
						flag = true;
						$("#error_output").append("<span>You must enter a valid date.</span>");
					}
					
					if ($("#birthdate_Year_ID").val().length < 4)
					{
						flag = true;
						$("#error_output").append("<span>You must enter a valid birth date.</span>");
					}
					
					if ($("#mother_name").val().length < 1)
					{
						flag = true;
						$("#error_output").append("<span>You must enter the litters mother.</span>");
					}
					if ($("#father_name").val().length < 1)
					{
						flag = true;
						$("#error_output").append("<span>You must enter the litters father.</span>");
					}
					
					<?php
					}
					?>
					
					if (!flag)
					{
						$("#editdog_form").submit()
					}
				});
				
				<?php if ($error)
				{
				?>
				$("#error_output").show();
				<?php
				}
				?>
			});
		</script>
	</head>
	<body>
		<div id="header"><h2>Edit Dog - <?php echo $dog['dog_name'];?></h2></div>
		<div id="menu">
			<ul>
				<li><a <?php if ($type == 1) { echo "id=\"current\"";} ?> href="dogs.php?type=1">Studs &amp; Bitches</a></li>
				<li><a <?php if ($type == 2) { echo "id=\"current\"";} ?> href="dogs.php?type=2">Dogs For Sale</a></li>
				<li><a <?php if ($type == 3) { echo "id=\"current\"";} ?> href="dogs.php?type=3">Puppies</a></li>
				<li><a href="gallery.php">Gallery</a></li>
				<li><a href="info.php">Info</a></li>
				<li><a href="options.php">Settings</a></li>
				<li><a class="menu-right" href="logout.php">Log Out</a></li>
			</ul>
		</div>
		<div id="wrapper">
			<div id="editor">
				<div id="err">
					<div id="error_output">
						<?php
							if ($error)
							{
						?>
							<span>Oops. Looks like we can't upload one of those images. Remember that images cannot be more than 1.5Mb in size. Images must also be in either jpeg, png or gif format.</span>
						<?php
							}
						?>
					</div>
				</div>
				<form id="editdog_form" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
					<input id="type" name="type" type="hidden" value="<?php echo $type;?>"></input>
					<input id="id" name="id" type="hidden" value="<?php echo $id;?>"></input>
					<input type="hidden" name="MAX_FILE_SIZE" value="1500000" />
					
					<label  for="dog_name"><?php if ($type == 3) { ?>Title:<?php } else { ?>Dog Name:<?php } ?></label>
					<input id="dog_name" name="dog_name" type="text" value="<?php if ($error) { echo $dname; } else { echo $dog['dog_name']; } ?>"></input>
					
					<label for="dog_text">Description:</label>
					<textarea id= "dog_text" name="dog_text" ><?php if ($error) { echo $dtext; } else { echo $dog['dog_text']; } ?></textarea>
					
					<?php
					if ($type != 3)
					{
					?>
					<label for="dog_sex">Sex:</label> 
					<select name="dog_sex">
						<?php
							while ($row = mysql_fetch_array($sexes))
							{
								if (!$error)
								{
									if ($row['id'] == $dog['sex'])
									{
										echo "<option selected=\"" . $dog['sex'] . "\" value=" . $row['id'] . ">" . $row['sex'] . "</option>";
									}
									else
									{
										echo "<option value=" . $row['id'] . ">" . $row['sex'] . "</option>";
									}
								}
								else
								{
									if ($row['id'] == $dsex)
									{
										echo "<option selected=\"" . $dsex . "\" value=" . $row['id'] . ">" . $row['sex'] . "</option>";
									}
									else
									{
										echo "<option value=" . $row['id'] . ">" . $row['sex'] . "</option>";
									}
								}
							}
						?>
					</select>
					
					<label for="dog_breed">Breed:</label>
					<select name="dog_breed">
						<?php
							while ($row = mysql_fetch_array($breeds))
							{
								if ($row['id'] < 4 or ($row['id'] == 4 and $type == 3)) 
								if (!$error)
								{
									if ($row['id'] == $dog['breed'])
									{
										echo "<option selected=\"" . $dog['breed'] . "\" value=" . $row['id'] . ">" . $row['breed'] . "</option>";
									}
									else
									{
										echo "<option value=" . $row['id'] . ">" . $row['breed'] . "</option>";
									}
								}
								else
								{
									if ($row['id'] == $dbreed)
									{
										echo "<option selected=\"" . $dog['breed'] . "\" value=" . $row['id'] . ">" . $row['breed'] . "</option>";
									}
									else
									{
										echo "<option value=" . $row['id'] . ">" . $row['breed'] . "</option>";
									}
								}
							}
						?>
					</select>
					<?php
						if ($type == 2)
						{
					?>
					<label for="dog_training">Training:</label>
					<select name="dog_training">
						<?php
							while ($row = mysql_fetch_array($training))
							{
								if (!$error)
								{
									if ($row['id'] == $dog['training'])
									{
										echo "<option selected=\"" . $dog['training'] . "\" value=" . $row['id'] . ">" . $row['training'] . "</option>";
									}
									else
									{
										echo "<option value=" . $row['id'] . ">" . $row['training'] . "</option>";
									}
								}
								else
								{
									if ($row['id'] == $dtraining)
									{
										echo "<option selected=\"" . $dog['training'] . "\" value=" . $row['id'] . ">" . $row['training'] . "</option>";
									}
									else
									{
										echo "<option value=" . $row['id'] . ">" . $row['training'] . "</option>";
									}
								}
							}
						?>
					</select><br />
					<?php
						}
					}
					if ($type == 3)
					{
					?>
						<div id="date">
							<label for="birthdate">Birth Date:</label>
							<script type="text/javascript">DateInput('birthdate', true, 'DD-MON-YYYY', '<?php echo $dog['birthdate']; ?>');</script>
							<label for="orderdate">Due To Leave:</label>
							<script type="text/javascript">DateInput('orderdate', true, 'DD-MON-YYYY', '<?php echo $dog['due_leave']; ?>');</script>
						</div>
						<?php
					}
					if ($type == 3 or $type == 2)
					{
							if ($dog['is_sold'] == 1)
							{	
						?>
						<label  for="is_sold">Has Been Sold?</label><br />
						<input class="checkbox" type="checkbox" name="is_sold" checked="yes" value="1" />
						<?php
							}
							else
							{
						?>
						<label  for="is_sold">Has Been Sold?</label><br />
						<input class="checkbox" type="checkbox" name="is_sold" value="1" />
						<?php
							}
					}
					if ($type == 3)
					{
						?>
						<br />
						<label for="mother_name">Mother's Name</label>
						<input id="mother_name" type="text" name="mother_name" value="<?php if ($error) {echo $mother_name; } else {echo $dog['mother_name'];} ?>"/>
						<label for="father_name">Father's Name</label>
						<input id="father_name" type="text" name="father_name" value="<?php if ($error) {echo $father_name; } else {echo $dog['father_name'];} ?>"/>
						
					<?php
					}
					?>
					
					<br />
					<br />
					<div id="images">
						<fieldset>
							<legend>Change Pedigree</legend>
							<?php if ($dog['pedigree'] != "") {?><img src="<?php echo $dog['pedigree_folder'] . $dog['pedigree'];?>" alt="<?php echo $dog['pedigree']?>" height="100" width="100" /><?php }?>
							<input name="dog_pedigree" type="file"/>
						</fieldset>
						<?php 

							$query = DBConnector::makeQuery("SELECT * FROM dog_images WHERE img_set=" . $dog['id'] . " ORDER BY series ASC");
							
							if (mysql_num_rows($query) > 0)
							{
						?>
						<fieldset>
							<legend>Remove Existing Images</legend>
							<?php
								while($row = mysql_fetch_array($query))
								{
							?>
							<div class="img_box">
								<img src="<?php echo $dog['img_folder'] . $row['filename'];?>" alt="<?php echo $row['filename']; ?>" height="100" width="100"/>
								<br /><label for="remove_<?php echo $row['series']; ?>">Remove</label><input class="checkbox" type="checkbox" name="remove_<?php echo $row['series']; ?>" />
							</div>
							<?php
								}
							?>
						</fieldset>
						<?php
							}
							DBConnector::closeConnection();
						?>
						<fieldset>
							<legend>Add More Images</legend>
							<input type="file" name="new_images[]" class="multi" accept="gif|png|jpg"/>
						</fieldset>
					</div>
					<input id="editdog_submit" class="button" name="button_submit" type="button" value="Edit Dog"></input>
				</form>
			</div>
		</div>
	</body>
</html>