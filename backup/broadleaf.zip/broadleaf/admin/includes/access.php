<?php
session_start();

if (!isset($_SESSION['logged_in']) or !isset($_COOKIE['logged_in_cms']))
{
	if (!isset($_SESSION['logged_in']))
	{
		$error = "unauthorised";
	}
	elseif (!isset($_COOKIE['logged_in_cms']))
	{
		$error = "timeout";
	}
	
	header("Location: index.php?error=$error");
	exit;
}
else
{
	setcookie("logged_in_cms", $_SESSION['user'], time()+1800);
}
?>