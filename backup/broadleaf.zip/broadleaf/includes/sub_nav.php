<div id="subnav">
	<ul id="subnavbar">
		<li><a class="subtab" <?php if ($breed == 1) { ?> id="current" <?php } ?> href="<?php echo $SERVER['PHP_SELF'];  ?>?breed=1">Labradors</a></li>					
		<li><a class="subtab" <?php if ($breed == 2) { ?> id="current" <?php } ?> href="<?php echo $SERVER['PHP_SELF'];  ?>?breed=2">Cocker Spaniels</a></li>
		<li><a class="subtab" <?php if ($breed == 3) { ?> id="current" <?php } ?> href="<?php echo $SERVER['PHP_SELF'];  ?>?breed=3">Springer Spaniels</a></li>
	</ul>
</div>