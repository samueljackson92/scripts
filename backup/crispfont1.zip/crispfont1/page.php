<?php get_header();?>
<style type="text/css">
	#content {width: 500px;}
</style>
<div id="content-wrap">
	<div id="content">
	<?php if (have_posts()) : ?>
	<?php while (have_posts()) : the_post(); ?>
		<div class="post">
			<h4 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h4>
			<div class="post-body">
				<?php the_content();?>
			</div>
		</div>
	<?php endwhile; ?>
	<?php else : ?>
		<h2>Not Found</h2>
	<?php endif; ?>
	</div>
</div>
<?php get_footer(); ?>