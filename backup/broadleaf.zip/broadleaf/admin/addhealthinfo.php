<?php
	require("includes/access.php");
	require("includes/dbconnector.php");
	require("includes/filemanager.php");
	require("includes/util.php");
	
	DBConnector::makeConnection();
	$no_health_tabs = mysql_num_rows(DBConnector::makeQuery("SELECT id FROM health_tabs"));
	if ($no_health_tabs >= 5)
	{
		header("Location: info.php?success=1");
		exit;
	}
	
	if (isset($_POST['title']))
	{
		$title = $_POST['title'];
		$title = Util::cleanInput($title);
		$text = $_POST['elm1'];
		$text = Util::cleanInput($text);
		
		DBConnector::makeQuery("INSERT INTO health_tabs (id, title, text) VALUES ('NULL', '$title', '$text')");
		header("Location: info.php?success=0");
		exit;
	}		
?>

<html>
	<head>
		<script type="text/javascript" src="js/jquery.js" language="javascript"></script>
		<script src="js/jquery.MultiFile.gallery.js" type="text/javascript" language="javascript"></script>
		
		<script type="text/javascript" src="js/tiny_mce/jquery.tinymce.js"></script>
		
		<script type="text/javascript">
			$().ready(function() {
				$('textarea.tinymce').tinymce({
					// Location of TinyMCE script
					script_url : '../admin/js/tiny_mce/tiny_mce.js',

					// General options
					width : "600",
					theme : "advanced",
					plugins : "autolink,lists,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,advlist",

					// Theme options
					theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
					theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
					theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
					theme_advanced_toolbar_location : "top",
					theme_advanced_toolbar_align : "left",
					theme_advanced_resizing : false,

					relative_urls : false,
					remove_script_host : false,
					convert_urls : false,
					// Drop lists for link/image/media/template dialogs
					template_external_list_url : "lists/template_list.js",
					external_link_list_url : "lists/link_list.js",
					external_image_list_url : "lists/image_list.js",
					media_external_list_url : "lists/media_list.js"
				});
				
				$("#addinfo_submit").click(function()
				{
					var flag = false;
					$("#error_output").show();
					$("#error_output").html("");
					
					if ($("#title").val() === "")
					{
						flag = true;
						$("#error_output").append("<span>You must enter a title.</span><br />");
					}
					
					if ($("#title").val().length > 20)
					{
						flag = true;
						$("#error_output").append("<span>The title can be no longer than 20 characters.</span><br />");
					}
					
					if ($("#elm1").val() === "")
					{
						flag = true;
						$("#error_output").append("<span>You must enter some content.</span>");
					}
					
					if (!flag)
					{
						$("#addinfo_form").submit()
					}
				});
			});
		</script>

		<link rel="stylesheet" type="text/css" href="css/admin-main.css">
		<link rel="stylesheet" type="text/css" href="css/admin-form.css">

		<style type="text/css">
			#editor{width: 700px;}
			form input {margin: 0px; margin-top: 10px; margin-bottom: 10px; width: 700px;}
			form textarea {height: 500px;}
			.button {margin-left: 0px;}
		</style>
		
		
		<title>Broadleaf Admin: Add Tab</title>
		
	</head>
	<body>
		<div id="header"><h2>Add Tab</h2></div>
		<div id="menu">
			<ul>
				<li><a href="dogs.php?type=1">Studs &amp; Bitches</a></li>
				<li><a href="dogs.php?type=2">Dogs For Sale</a></li>
				<li><a href="dogs.php?type=3">Puppies</a></li>
				<li><a href="gallery.php">Gallery</a></li>
				<li><a id="current" href="info.php">Info</a></li>
				<li><a href="options.php">Settings</a></li>
				<li><a class="menu-right" href="logout.php">Log Out</a></li>
			</ul>
		</div>
		<div id="wrapper">
			<div id="editor">
				<div id="err">
					<div id="error_output">

					</div>
				</div>
				<form id="addinfo_form" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
					<label for="title">Title:</label><br />
					<input type="text" name="title" id="title"/>
					<div
						<!-- Gets replaced with TinyMCE, remember HTML in a textarea should be encoded -->
						<div>
							<textarea id="elm1" name="elm1" rows="15" cols="80" style="width: 80%" class="tinymce">
							</textarea>
						</div>
						<br />
						<input id="addinfo_submit" class="button" type="button" name="addinfo_submit" value="Add Tab" />
					</div>
				</form>
			</div>
		</div>
	</body>
</html>