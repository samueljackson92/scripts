<?php
require_once('dbconnector.php');
require_once('error_enums.php');
require_once('util.php');

class Auth {
	//check if data entered is present in our database
	public function connect_user($user, $password) {
		DBConnector::make_con();
		
		if (!Util::validate_email($user)) {
			return false;
		}
		
		$user = Util::clean_input($user);
		$password = Util::clean_input($password);
		
		$resp = DBConnector::make_query("SELECT id, user_name, password FROM users WHERE user_name='$user'");
		
		if(mysql_num_rows($resp) == 1) {
			$resp = mysql_fetch_array($resp);
			if (sha1($password) == $resp['password']) {
				//data correct
				return true;
			}
		}
		
		return false;
	}
	
	//create a new session for the validated user
	private function new_user_session($user) {
		session_start();
		$resp = DBConnector::fetch_array("SELECT id, user_name, nice_name FROM users WHERE user_name='$user'");
		$_SESSION['id'] = session_id();
		$_SESSION['nice_name'] = $resp['nice_name'];
		$_SESSION['user_id'] = $resp['id'];
		
		setcookie("user_auth", $_SESSION['user_id'], time() + 3600);
	}
	
	public static function destroy_user_session() {
		session_start();
		$_SESSION = array();
		session_destroy();
		setcookie("user_auth", time() - 3600);
	}
	
	public static function log_out($page) {
		Auth::destroy_user_session();
		header("Location: $page");
	}
	
	public static function check_auth() {
		session_start();
		
		if (isset($_SESSION['id']) && isset($_SESSION['user_id'])) {
			if(isset($_COOKIE['user_auth']) && 
				$_COOKIE['user_auth'] == $_SESSION['user_id']) {
					return true;
			}
		}
		
		return false;
	}
	
	public function auth_successful($user, $page) {
		$this->new_user_session($user);
		header("Location: $page");
	}
	
	public function auth_failed($page) {
		header("Location: $page?error=" . ErrorEnums::LOGIN_AUTH_ERROR);
	}
}
?>