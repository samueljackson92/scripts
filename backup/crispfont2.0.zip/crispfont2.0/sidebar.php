<div id="feeds">
	<a href="?feed=rss" ><img src="<?php bloginfo('template_directory'); ?>/images/rss.png" alt="RSS feeds"/></a>
	<a href="http://twitter.com/sljack92" ><img src="<?php bloginfo('template_directory'); ?>/images/twitter.png" alt="Twitter feed"/></a>
	<a href="http://www.linkedin.com/pub/samuel-jackson/53/a1b/414"><img src="<?php bloginfo('template_directory'); ?>/images/linkedin.png" alt="LinkedIn profile"/></a>
</div>
<ul id="sidebar">
<?php if ( !function_exists('dynamic_sidebar')
        || !dynamic_sidebar() ) : ?>
<?php endif; ?>
</ul>