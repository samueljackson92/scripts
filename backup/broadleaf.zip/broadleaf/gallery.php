<?php
require("admin/includes/dbconnector.php");

if (!isset($_GET['breed']))
{
	$breed = 1;
}
else
{
	$breed = $_GET['breed'];
}


DBConnector::makeConnection();

$q = DBConnector::makeQuery("SELECT * FROM gallery ORDER BY id DESC");

?>

<html>
	<head>
		<?php include("includes/meta.php"); ?>
		<link rel="stylesheet" type="text/css" href="css/galleriffic.css"/>
		<script type="text/javascript" src="js/jquery-1.3.2.js"></script>
		<script type="text/javascript" src="js/jquery.galleriffic.js"></script>
		<script type="text/javascript" src="js/jquery.opacityrollover.js"></script>
	</head>
	<body>
		<div id="container">
			<?php include("includes/header.php"); ?>
			
			<div id="content">
				<!-- Start Advanced Gallery Html Containers -->
				<div id="gallery" class="content">
				<div id="caption" class="caption-container"></div>
					<div id="controls" class="controls"></div>
					<div class="slideshow-container">
						<div id="loading" class="loader"></div>
						<div id="slideshow" class="slideshow"></div>
					</div>
					
				</div>
				<div id="thumbs" class="navigation">
					<ul class="thumbs noscript">
						<?php
							if (mysql_num_rows($q) > 0)
							{
								while ($img = mysql_fetch_array($q))
								{
						?>
						<li>
							<a class="thumb"  href="admin/media/gallery/<?php echo $img['filename']; ?>" title="Title #0">
								<img height="80" width="80"src="admin/media/gallery/<?php echo $img['filename']; ?>" alt="<?php echo $img['image_name']; ?>" />
							</a>
							<div class="caption">
								<div class="image-title"><?php echo html_entity_decode($img['image_name']); ?></div>
								<div class="image-desc"><?php echo html_entity_decode($img['caption']); ?></div>
							</div>
						</li>
						<?php
								}
							}
							else
							{
						?>
						<span id="nodogs">We currently have no images in the gallery.</span>
						<?php
							}
						?>
					</ul>
				</div>
				<div style="clear: both;"></div>
			</div>
			<div id="footer">
			</div>
			<script type="text/javascript">
				// We only want these styles applied when javascript is enabled
				$('div.navigation').css({'width' : '300px', 'float' : 'left'});
				$('div.content').css('display', 'block');

				$(document).ready(function() {				
					// Initialize Minimal Galleriffic Gallery
					
					$('#thumbs').galleriffic({
						delay:                     3000,
						numThumbs:                 7,
						preloadAhead:              20,
						enableBottomPager:         true,
						maxPagesToShow:            7,
						imageContainerSel:      '#slideshow',
						captionContainerSel:	'#caption',
						loadingContainerSel:   	'#loading'
					});
				});
				
				
			</script>
		</div>
	</body>
		
</html>
