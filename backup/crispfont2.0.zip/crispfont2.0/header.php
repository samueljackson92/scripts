<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" 
"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
		<title><?php bloginfo('name');?></title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link type="text/css" rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>"></link>
		<?php wp_head();?>
	</head>
	<body>
	<div id="content-wrap">
		<div id="header">
			<div id="header-content"> 
				<h5><a href="<?php echo get_option('home'); ?>"><?php bloginfo('name'); ?></a></h5>
				<div id="pages">
					<ul>
						<?php wp_list_pages('sort_column=menu_order&depth=1&title_li=');?>
					</ul>
				</div>
			</div>
		</div>