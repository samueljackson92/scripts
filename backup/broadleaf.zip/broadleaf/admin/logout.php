<?php 
session_start();
if (isset($_SESSION['logged_in']))
{
	unset($_SESSION['logged_in']);
	unset($_COOKIE['logged_in_cms']);
}
session_destroy ();

header("Location: index.php");
?>