<?php
require_once('server_settings.php');
class DBConnector
{	

	private static $con = null;
	
	public function __construct() {
		$this->make_con();
	}
	 
	public static function make_con ()
	{
		$settings = ServerSettings::get_db_settings();
		
		$con = mysql_connect($settings['dbhost'], $settings['dbuser'], $settings['dbpassword']);
		
		if (!$con)
		{
			die(mysql_error());
		}
		
		mysql_select_db($settings['dbname'], $con) or die(mysql_error());
	}
	
	public static function make_query ($query)
	{
		if ($con == null)
		{
			DBConnector::make_con();
		}
		
		$result = mysql_query($query) or die(mysql_error());
		return $result;
	}
	
	public static function fetch_array($query) {
		return mysql_fetch_array(DBConnector::make_query($query));
	}
	
	public static function close_con ()
	{
		$result = mysql_close() or die(mysql_error());
		return $result;
	}
}
?>