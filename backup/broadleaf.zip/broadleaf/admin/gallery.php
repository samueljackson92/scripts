<?php
	require("includes/access.php");
	require("includes/dbconnector.php");
	require("includes/filemanager.php");
	DBConnector::makeConnection();
	
	if (isset($_POST['remove']))
	{	
		$row = mysql_fetch_array(DBConnector::makeQuery("SELECT * FROM gallery WHERE id=" . $_POST['remove']));
		FileManager::removeFile("media/gallery/" . $row['filename']);
		DBConnector::makeQuery("DELETE FROM gallery WHERE id=" . $_POST['remove']);
	}
	
	$numrows = mysql_num_rows(DBConnector::makeQuery("SELECT * FROM gallery"));
	
	$rowsperpage = 10;
	$totalpages = ceil($numrows / $rowsperpage);

	if (isset($_GET['currentpage']) && is_numeric($_GET['currentpage'])) 
	{
	   $currentpage = (int) $_GET['currentpage'];
	} 
	else 
	{
	   $currentpage = 1;
	}

	if ($currentpage > $totalpages) 
	{
	   $currentpage = $totalpages;
	}
	
	if ($currentpage < 1)
	{
	   $currentpage = 1;
	}
	
	$offset = ($currentpage - 1) * $rowsperpage;
	
	$q = DBConnector::makeQuery("SELECT * FROM gallery ORDER BY id DESC LIMIT $offset, $rowsperpage");
?>

<html>
	<head>		
		<script type="text/javascript" src="js/jquery.js"></script>
		<title>Broadleaf Admin: Gallery</title>
		<link rel="stylesheet" type="text/css" href="css/admin-main.css">
		<link rel="stylesheet" type="text/css" href="css/admin-gallery.css">
		
		<script type="text/javascript">
			$(document).ready(function ()
			{	
				$("#close_output").click(function()
				{
					$("#output").slideUp("normal");
				});
				
				$(".remove").click(function()
				{
					$("#confirm_remove").slideUp("normal");
					var id = parseInt($(this).attr("id"));
					$("#confirm_remove").slideDown("normal");
					$("#remove").val(id);
				});
				
				$("#confirm_delete").click(function ()
				{
					$("#confirm_remove").slideUp("normal", function ()
					{
						$("#confirm_remove > form").submit();
					});
				});
				
				$("#cancel_delete").click(function()
				{
					$("#confirm_remove").slideUp("normal");
				});
				
				$("#close_output").click(function()
				{
					$("#output").slideUp("normal");
					$("#output").hide();
				});
			});
		</script>
	</head>
	<body>
		<div id="header"><h2>Gallery Editor</h2></div>
		<div id="menu">
			<ul>
				<li><a href="dogs.php?type=1">Studs &amp; Bitches</a></li>
				<li><a href="dogs.php?type=2">Dogs For Sale</a></li>
				<li><a href="dogs.php?type=3">Puppies</a></li>
				<li><a id="current" href="gallery.php">Gallery</a></li>
				<li><a href="info.php">Info</a></li>
				<li><a href="options.php">Settings</a></li>
				<li><a class="menu-right" href="logout.php">Log Out</a></li>
			</ul>
		</div>
		<div id="wrapper">
			<div id="output">
				<?php
				if (isset($_GET['success']) and is_numeric($_GET['success']))
				{
					$bool = (int) $_GET['success'];
					if ($bool == 0)
					{
						echo "<span>Database successfully altered!";
						echo "<input id=\"close_output\" type=\"button\" value=\"Close\"></input></span>";
					}
				}
				?>
			</div>
			<div id="confirm_remove">
				<span>Are you sure you wish to remove this image from the database?</span>
				<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
					<input id="remove" type="hidden" name="remove" />
					<input id="confirm_delete" type="button" value="Confirm"></input>
					<input id="cancel_delete" type="button" value="Cancel"></input>
				</form>
			</div>
			<div id="options">
				<div class="shortButton"><a href="addimages.php"><img src="css/images/add.png" alt="add" /></a></div>
				<?php

					$range = 3;

					if ($currentpage > 1) {
					   echo " <a class=\"pagination\" href='{$_SERVER['PHP_SELF']}?currentpage=1'>First</a> ";
					   $prevpage = $currentpage - 1;
					   echo " <a class=\"pagination\" href='{$_SERVER['PHP_SELF']}?currentpage=$prevpage'>Prev</a> ";
					}

					for ($x = ($currentpage - $range); $x < (($currentpage + $range) + 1); $x++) {
					   if (($x > 0) and ($x <= $totalpages)) 
					   {
							if ($x == $currentpage) {
								echo " <a id=\"currentpage\" href=\"#\">$x</a>";
							} 
							else 
							{
								echo "<a class=\"pagination\" href='{$_SERVER['PHP_SELF']}?currentpage=$x'>$x</a> ";
							} 
					   } 
					} 

					if ($currentpage != $totalpages) {
					   $nextpage = $currentpage + 1;
					   echo " <a class=\"pagination\" href='{$_SERVER['PHP_SELF']}?currentpage=$nextpage'>Next</a> ";
					   echo " <a class=\"pagination\" href='{$_SERVER['PHP_SELF']}?currentpage=$totalpages'>Last</a> ";
					} 
				?>
			</div>
			<div id="gallery">
				<ul>
					<?php
						while($row = mysql_fetch_array($q))
						{
					?>
					<li>
						<img class="gall_img" src="media/gallery/<?php echo $row['filename']; ?>" alt="<?php echo html_entity_decode($row['image_name']); ?>" />
						<div class="image_data">
							<h4><?php echo html_entity_decode($row['image_name']); ?></h4>
							<div class="options">
								<a href="editimage.php?id=<?php echo $row['id']; ?>"><img src="css/images/edit.png" alt="edit" /></a>
								<a id="<?php echo $row['id']; ?>" class="remove" href="#"><img src="css/images/remove.png" alt="remove" /></a>
							</div>
						</div>
					</li>
					<?php
						}
					?>
				</ul>
			</div>
		</div>
	</body>
</html>