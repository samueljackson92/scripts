<?php
	require("includes/access.php");
	require("includes/dbconnector.php");
	require("includes/filemanager.php");
	require("includes/util.php");
	
	DBConnector::makeConnection();
	$sexes = DBConnector::makeQuery("SELECT * FROM sex WHERE id=1 OR id=2");
	$breeds = DBConnector::makeQuery("SELECT * FROM breed LIMIT 3");
	$training = DBConnector::makeQuery("SELECT * FROM training WHERE id=2 OR id=3");
	$error = false;
	
	if (isset($_POST['dog_name']))
	{

		$errorargs = array();
		$imagenames = array();
		
		//get post variables, sanatise.
		$dname = Util::cleanInput($_POST['dog_name']);
		$folder_name = stripslashes($dname);
		$folder_name = preg_replace("/[^A-Za-z0-9_]/", "", $folder_name);
		$dtext = Util::cleanInput($_POST['dog_text']);		
		
		$mother_name = Util::cleanInput($_POST['mother_name']);
		$father_name = Util::cleanInput($_POST['father_name']);
		
		$leavedate = $_POST['orderdate'];
		$birthdate = $_POST['birthdate'];
		
		$sold = $_POST['is_sold'];

		if (isset($_POST['dog_sex'])) { $dsex = $_POST['dog_sex']; } else { $dsex = 3;}
		if (isset($_POST['dog_breed'])) { $dbreed = $_POST['dog_breed']; } else { $dbreed = 4;}
		if (isset($_POST['dog_training'])) { $dtraining = $_POST['dog_training']; } else { $dtraining = 1;}

		
		$timesalt = time();
		$pedigree_path = "media/pedigree/" . $folder_name  . $timesalt . "/";
		
		if($_FILES['dog_pedigree']['name'] != "")
		{
			$dpedigree = $_FILES['dog_pedigree']['name'];
			$tmp_name = $_FILES['dog_pedigree']['tmp_name'];
			
			if($_FILES['dog_pedigree']['error'][$i] != 0 and $_FILES['dog_pedigree']['error'][$i] != 4)
			{
				$error = true;
			}
			
			if($_FILES['dog_pedigree']['size'][$i] > 1500000)
			{
				$error = true;
			}
			
			while (true)
			{
				if (file_exists($target_path . $dpedigree))
				{
					$i++;
					$ext = substr(basename($dpedigree), -4);
					$dpedigree = $dpedigree . "(" . $i . ")" . $ext;
				}
				else
				{
					break;
				}
			}
			
			//upload pedigree to server
			if (!FileManager::uploadFile($dpedigree, $tmp_name, $pedigree_path))
			{
				$error = true;
			}
		}
			
			
		$target_path = "media/images/" . $folder_name . $timesalt . "/";

		//upload images to server
		for ($i = 0; $i < count($_FILES['dog_images']['name']); $i++)
		{
			$fname = $_FILES['dog_images']['name'][$i];
			$tmp_name = $_FILES['dog_images']['tmp_name'][$i];
			
			
			if ($fname != "")
			{
				array_push($imagenames, $fname);
				
				if($_FILES['dog_images']['error'][$i] != 0 and $_FILES['dog_images']['error'][$i] != 4)
				{
					$error = true;
				}
				
				if($_FILES['dog_images']['size'][$i] > 1500000)
				{
					$error = true;
				}
				
				while (true)
				{
					if (file_exists($target_path . $fname))
					{
						$j++;
						$ext = substr(basename($fname), -4);
						$fname = $fname . "(" . $j . ")" . $ext;
					}
					else
					{
						break;
					}
				}
			
				if (!FileManager::uploadFile($fname, $tmp_name, $target_path))
				{
					$error = true;
				}
			}
		}
		
		//submit data to database if everything is ok
		if (!$error)
		{
			$target_path = addslashes($target_path);
			$pedigree_path = addslashes($pedigree_path);
			$query = "INSERT INTO dogs (id, dog_name, dog_text, breed, sex, type, training, mother_name, father_name, birthdate, due_leave, is_sold, pedigree, salt, img_folder, pedigree_folder) 
			VALUES ('NULL', '$dname', '$dtext', '$dbreed', '$dsex', '".$_POST['type']."', '$dtraining', '$mother_name', '$father_name', '$birthdate', '$leavedate', '$sold', '$dpedigree', '$timesalt', '$target_path', '$pedigree_path');";
			DBConnector::makeQuery($query);
			
			$id = mysql_insert_id();
			
			foreach ($imagenames as $key => $img)
			{
				DBConnector::makeQuery("INSERT INTO dog_images (id, filename, img_set, series) VALUES ('NULL', '$img', '$id', '$key')");
			}
			
			header("Location: dogs.php?type=" . $_POST['type'] . "&success=0");
		}
	}
	
	DBConnector::closeConnection();
	
	if (isset($_GET['type']) and is_numeric($_GET['type']))
	{
		$type = (int) $_GET['type'];
	}
	elseif (isset($_POST['type']) and is_numeric($_POST['type']))
	{
		$type = (int) $_POST['type'];
	}
	else
	{
		header("Location: dogs.php?type=1");
		exit;
	}

?>

<html>
	<head>
		<script type="text/javascript" src="js/jquery.js" language="javascript"></script>
		<script src="js/jquery.MultiFile.js" type="text/javascript" language="javascript"></script>
		<script type="text/javascript" src="js/calender/calendarDateInput.js" language="javascript">
			/***********************************************
			* Jason's Date Input Calendar- By Jason Moon http://calendar.moonscript.com/dateinput.cfm
			* Script featured on and available at http://www.dynamicdrive.com
			* Keep this notice intact for use.
			***********************************************/
		</script>
		<link rel="stylesheet" type="text/css" href="css/admin-main.css">
		<link rel="stylesheet" type="text/css" href="css/admin-form.css">
		<title>Broadleaf Admin: Add Dog</title>
		
		<script type="text/javascript">
			$(document).ready(function ()
			{
				$("#adddog_submit").click(function()
				{
					var flag = false;
					$("#error_output").html("");
					
					if ($("#dog_name").val() === "")
					{
						flag = true;
						$("#error_output").append("<span>You must enter a name for the dog.</span><br />");
					}
					
					if ($("#dog_text").val() === "")
					{
						flag = true;
						$("#error_output").append("<span>You must enter a description for the dog.</span>");
					}
					<?php
					if ($type == 3)
					{
					?>
					var dateObj = new Date();
					if ($("#orderdate_Year_ID").val().length < 4 || $("#orderdate_Year_ID").val() < dateObj.getFullYear())
					{
						flag = true;
						$("#error_output").append("<span>You must enter a valid date.</span>");
					}
					else if ($("#orderdate_Year_ID").val() == dateObj.getFullYear() && $("#orderdate_Month_ID option:selected").val() < dateObj.getMonth())
					{
					
						flag = true;
						$("#error_output").append("<span>You must enter a valid date.</span>");
					}
					
					else if ($("#orderdate_Month_ID option:selected").val() == dateObj.getMonth() && $("#orderdate_Day_ID option:selected").val() < dateObj.getDate())
					{
						flag = true;
						$("#error_output").append("<span>You must enter a valid date.</span>");
					}
					
					
					
					if ($("#birthdate_Year_ID").val().length < 4 || $("#birthdate_Year_ID").val() > dateObj.getFullYear())
					{
						flag = true;
						$("#error_output").append("<span>You must enter a valid birth date.</span>");
					}
					else if ($("#birthdate_Year_ID").val() == dateObj.getFullYear() && $("#birthdate_Month_ID option:selected").val() > dateObj.getMonth())
					{
					
						flag = true;
						$("#error_output").append("<span>You must enter a valid birth date.</span>");
					}
					
					else if ($("#birthdate_Month_ID option:selected").val() == dateObj.getMonth() && $("#birthdate_Day_ID option:selected").val() > dateObj.getDate())
					{
						flag = true;
						$("#error_output").append("<span>You must enter a valid birth date.</span>");
					}
					
					
					
					
					if ($("#mother_name").val().length < 1)
					{
						flag = true;
						$("#error_output").append("<span>You must enter the litters mother.</span>");
					}
					if ($("#father_name").val().length < 1)
					{
						flag = true;
						$("#error_output").append("<span>You must enter the litters father.</span>");
					}
					
					<?php
					}
					?>
					
					if (!flag)
					{
						$("#adddog_form").submit()
					}
					else
					{
						$("#error_output").show();
					}
				});
				<?php if ($error)
				{
				?>
				$("#error_output").show();
				<?php
				}
				?>
			});
			

		</script>
	</head>
	<body>
		<div id="header"><h2>Add Dog</h2></div>
		<div id="menu">
			<ul>
				<li><a <?php if ($type == 1) { echo "id=\"current\"";} ?> href="dogs.php?type=1">Studs &amp; Bitches</a></li>
				<li><a <?php if ($type == 2) { echo "id=\"current\"";} ?> href="dogs.php?type=2">Dogs For Sale</a></li>
				<li><a <?php if ($type == 3) { echo "id=\"current\"";} ?> href="dogs.php?type=3">Puppies</a></li>
				<li><a href="gallery.php">Gallery</a></li>
				<li><a href="info.php">Info</a></li>
				<li><a href="options.php">Settings</a></li>
				<li><a class="menu-right" href="logout.php">Log Out</a></li>
			</ul>
		</div>
		<div id="wrapper">
			<div id="editor">
				<div id="err">
					<div id="error_output">
						<?php
							if ($error)
							{
						?>
							<span>Oops. Looks like we can't upload one of those images. Remember that images cannot be more than 1.5Mb in size. Images must also be in either jpeg, png or gif format.</span>
						<?php
							}
						?>
					</div>
				</div>
				<form id="adddog_form" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
						<input id="type" name="type" type="hidden" value="<?php echo $type; ?>"></input>
						<input type="hidden" name="MAX_FILE_SIZE" value="1500000" />
						<label  for="dog_name"><?php if ($type == 3) { ?>Title:<?php } else { ?>Dog Name:<?php } ?></label>
						<input id="dog_name" name="dog_name" "type="text" value="<?php if ($error) { echo $dname; } ?>"></input>
						<label for="dog_text">Description:</label>
						<textarea id= "dog_text" name="dog_text" ><?php if ($error) { echo $dtext; } ?></textarea>
						<?php
						if ($type != 3)
						{
						?>
						<label for="dog_sex">Sex:</label> 
						<select name="dog_sex">
							<?php
								while ($row = mysql_fetch_array($sexes))
								{
									if ($error == true and $row['id'] == $dsex)
									{
										echo "<option selected=\"$dsex\" value=" . $row['id'] . ">" . $row['sex'] . "</option>";
									}
									else
									{
										echo "<option value=" . $row['id'] . ">" . $row['sex'] . "</option>";
									}
								}
							?>
						</select>
						<label for="dog_breed">Breed:</label>
						<select name="dog_breed">
							<?php
								while ($row = mysql_fetch_array($breeds))
								{
									if ($error == true and $row['id'] == $dbreed)
									{
										echo "<option selected=\"$dbreed\" value=" . $row['id'] . ">" . $row['breed'] . "</option>";
									}
									else
									{
										echo "<option value=" . $row['id'] . ">" . $row['breed'] . "</option>";
									}
								}
							?>
						</select>
						<?php
							if ($type == 2)
							{
						?>
						<label for="dog_training">Training:</label>
						<select name="dog_training">
							<?php
								while ($row = mysql_fetch_array($training))
								{
									if ($error == true and $row['id'] == $dtraining)
									{
										echo "<option selected=". $dtraining ." value=" . $row['id'] . ">" . $row['training'] . "</option>";
									}
									else
									{
										echo "<option value=" . $row['id'] . ">" . $row['training'] . "</option>";
									}
								}
							?>
						</select><br />
						<?php
							}
						}
						
						if ($type == 3 or $type == 2)
						{
						?>
					
					<label for="is_sold">Has Been Sold?</label><br />
					<input class="checkbox" type="checkbox" name="is_sold" value="1" />
					<br />
					<?php
						}
					if ($type == 3)
					{
					?>
						<div id="date">
							<label for="birthdate">Birth Date:</label>
							<script type="text/javascript">DateInput('birthdate', true, 'DD-MON-YYYY');</script>
							<label for="orderdate">Due To Leave:</label>
							<script type="text/javascript">DateInput('orderdate', true, 'DD-MON-YYYY');</script>
						</div>
						<label for="mother_name">Mother's Name</label>
						<input id="mother_name" type="text" name="mother_name"/>
						<label for="father_name">Father's Name</label>
						<input id="father_name" type="text" name="father_name"/>
					<?php
					}
					?>
					<fieldset>
						<legend>Upload Pedigree</legend>
						<input name="dog_pedigree" type="file" />
					</fieldset>
					<fieldset>
						<legend>Upload Images</legend>
						<input type="file" name="dog_images[]" class="multi" accept="gif|png|jpg"/>
					</fieldset>
					<input id="adddog_submit" class="button" name="button_submit" type="button" value="Add Dog"></input>
				</form>
			</div>
		</div>
	</body>
</html>