<?php 
class ServerSettings
{
	public static function get_db_settings()
	{	
		//database variables
		$settings['dbuser'] = 'root';
		$settings['dbpassword'] = 'fforde';
		$settings['dbhost'] = 'localhost';
		$settings['dbname'] = 'jotter_cms';
		
		return $settings;
	}
	
	public static function get_crypt_settings() {
		$settings['site_salt'] = 'OdEVKqbXpGglQyE02aG7';
		
		return $settings;
	}
}
?>