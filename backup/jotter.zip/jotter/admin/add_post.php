<?php
require_once('includes/auth.php');
require_once('includes/posts.php');
if (!Auth::check_auth()) {
	Auth::log_out("login.php");
}

?>
<html>
<head>
	<link href="css/general.css" type="text/css" rel="stylesheet" />
	<link href="css/form.css" type="text/css" rel="stylesheet" />
	<script type="text/javascript" src="js/jquery-1.6.4.min.js"></script>
	<script type="text/javascript" src="js/tinymce/jscripts/tiny_mce/tiny_mce.js" ></script >
	<script type="text/javascript" >
		tinyMCE.init({
			mode : "textareas",
			theme : "advanced",
			plugins : "emotions,spellchecker,advhr,insertdatetime,preview", 
					
			// Theme options - button# indicated the row# only
			theme_advanced_buttons1 : "newdocument,|,bold,italic,underline,|,justifyleft,justifycenter,justifyright,fontselect,fontsizeselect,formatselect",
			theme_advanced_buttons2 : "cut,copy,paste,|,bullist,numlist,|,outdent,indent,|,undo,redo,|,link,unlink,anchor,image,|,code,preview,|,forecolor,backcolor",
			theme_advanced_buttons3 : "insertdate,inserttime,|,spellchecker,advhr,,removeformat,|,sub,sup,|,charmap,emotions",      
			theme_advanced_toolbar_location : "top",
			theme_advanced_toolbar_align : "left",
			theme_advanced_statusbar_location : "bottom",
			theme_advanced_resizing : true
		});
	</script >
</head>
<body>
	<?php include_once('includes/header.php');?>
	<div id="content">
		<form id="text_editor">
			<input type="text" />
			<textarea name="text" cols="50" rows="15" > 
			This is some content that will be editable with TinyMCE.
			</textarea>
		</form>
	</div>
	<?php include_once('includes/footer.php');?>
</body>
</html>