<?php
require("admin/includes/dbconnector.php");

if (!isset($_GET['breed']))
{
	$breed = 1;
}
else
{
	$breed = $_GET['breed'];
}


DBConnector::makeConnection();

$q = DBConnector::makeQuery("SELECT * FROM dogs WHERE type=2 AND breed=$breed ORDER BY id DESC");

?>

<html>
	<head>
		<?php include("includes/meta.php"); ?>
		<script type="text/javascript" src="js/jquery-1.3.2.js"></script>
		<script type="text/javascript" src="js/jquery.galleriffic.js"></script>
	</head>
	<body>
		<div id="container">
			<?php include("includes/header.php"); ?>
			
			<div id="content">
				<h2>Sale Dogs</h2>				
				<?php include("includes/sub_nav.php"); ?>
				<div id="dogs">
					<?php
					$keys = array();
					if (mysql_num_rows($q) > 0)
					{
						while ($dog = mysql_fetch_array($q))
						{
							array_push($keys, $dog['id']);
							$training = mysql_fetch_array(DBConnector::makeQuery("SELECT * FROM training WHERE id=" . $dog['training']));
					?>
					<div class="dog">
						<div class="dog-wrap">
							<div class="gallery content">
								<div class="slideshow-container">
									<div id="slideshow_<?php echo $dog['id']; ?>" class="slideshow"></div>
								</div>
								<div class="caption-container"></div>
							</div>
							
							<div class="dogtext">
								<h3><?php echo $dog['dog_name']; ?></h3>
								<small><b>Training Status:</b> <?php echo $training['training']; ?></small>
								<p><?php echo $dog['dog_text'];?></p>
								<a href="admin/<?php echo $dog['pedigree_folder'] . $dog['pedigree'];?>">Pedigree Certificate</a>
								<?php
									if ($dog['is_sold'] == 1)
									{
								?>
									<h4 class="sold">This dog has been sold.</h4>
								<?php
									}
								?>
							</div>
						</div>

						<div class="mini_gallery">
							<div id="thumbs_<?php echo $dog['id']; ?>" class="thumbs navigation">
								<ul class="thumbs noscript">
								<?php
								$images = DBConnector::makeQuery("SELECT * FROM dog_images WHERE img_set=" . $dog['id']. " ORDER BY series ASC");
								
								while($img = mysql_fetch_array($images))
								{
								?>
									<li>
										<a class="thumb" href="admin/<?php echo $dog['img_folder'] . $img['filename'];?>" title="<?php echo $img['filename'];?>">
											<img height="100" width="100" src="admin/<?php echo $dog['img_folder'] . $img['filename'];?>" alt="<?php echo $img['filename'];?>" />
										</a>
									</li>
								<?php
								}
								?>
								</ul>
							</div>
						</div>
					</div>
						
					<?php
						}
					}
					else
					{
					?>
					<span id="nodogs">We currently have no dogs of this breed available.</span>
					<?php
					}
					?>
				</div>
			</div>
			<div id="footer">
			</div>
			<script type="text/javascript">
				// We only want these styles applied when javascript is enabled
				$('div.navigation').css({'width' : '300px', 'float' : 'left'});
				$('div.content').css('display', 'block');

				$(document).ready(function() {				
					// Initialize Minimal Galleriffic Gallery
					<?php 
						foreach($keys as $key)
						{
					?>
					$('#thumbs_<?php echo $key; ?>').galleriffic({
						imageContainerSel:      '#slideshow_<?php echo $key; ?>'
					});
					<?php
						}
					?>
				});
			</script>
		</div>
	</body>
		
</html>
