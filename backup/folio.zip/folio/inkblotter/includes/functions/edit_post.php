<?php
	require_once('../access.php');
	require_once('../dbconnector.php');
	$db = new DataBase;
	
	$db->makeConnection();

	$id = $_POST['id'];
	$title = $_POST['title'];
	$tagline = $_POST['tagline'];
	$text = $_POST['text'];
	$text = addslashes ($text);
	$cat = $_POST['cat'];
	$datetime = date('l jS \of F Y h:i:s A');
	
	$db->makeQuery('UPDATE cmsarticles 
					 SET title="'.$title.'", 
					 tagline="'.$tagline.'",
					 section="'.$cat.'",
					 thearticle="'.$text.'",
					 edittime="'.$datetime.'"
					 WHERE ID="'.$id.'"');

	$db->closeConnection();
?>