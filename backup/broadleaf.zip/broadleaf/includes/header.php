
<div id="header">	
	<?php
	$d = date("n");
	if ($d == 12)
	{
	?>
	<img src="css/images/base/header-winter.jpg" alt="Header"/>
	<?php
	}
	else
	{
	?>
	<img src="css/images/base/header.jpg" alt="Header"/>
	<?php
	}
	?>
</div>

<div id="navlist">
	<ul id="navbar">
		<li><a <?php if(basename($_SERVER['PHP_SELF']) == "index.php") {echo "id=\"header_current\"";} ?> class="tab" href="index.php">Home</a>						
		<li><a <?php if(basename($_SERVER['PHP_SELF']) == "studs.php") {echo "id=\"header_current\"";} ?> class="tab" href="studs.php">Studs</a></li>
		<li><a <?php if(basename($_SERVER['PHP_SELF']) == "bitches.php") {echo "id=\"header_current\"";} ?> class="tab" href="bitches.php">Bitches</a></li>
		<li><a <?php if(basename($_SERVER['PHP_SELF']) == "saledogs.php") {echo "id=\"header_current\"";} ?> class="tab" href="saledogs.php">Dogs For Sale</a></li>
		<li><a <?php if(basename($_SERVER['PHP_SELF']) == "puppies.php") {echo "id=\"header_current\"";} ?> class="tab" href="puppies.php">Puppies</a></li>
		<li><a <?php if(basename($_SERVER['PHP_SELF']) == "gallery.php") {echo "id=\"header_current\"";} ?> class="tab" href="gallery.php">Gallery</a></li>
		<li><a <?php if(basename($_SERVER['PHP_SELF']) == "info.php") {echo "id=\"header_current\"";} ?> class="tab" href="info.php">Info</a></li>
	</ul>
</div>