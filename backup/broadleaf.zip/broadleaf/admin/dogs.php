<?php
	require("includes/access.php");
	require("includes/dbconnector.php");
	require("includes/filemanager.php");
	DBConnector::makeConnection();
	$type = 1;
	
	if (isset($_GET['type']) and is_numeric($_GET['type']))
	{
		$type = (int) $_GET['type'];
	}
	
	if (isset($_POST['removal_id']))
	{	
		$q = mysql_fetch_array(DBConnector::makeQuery("SELECT * FROM dogs WHERE id=" . $_POST['removal_id']));
		
		
		$target_path = $q['pedigree_folder'];
		FileManager::removeDir(substr($target_path, 0, -1));
		$target_path = $q['img_folder'];
		FileManager::removeDir(substr($target_path, 0, -1));
		
		DBConnector::makeQuery("DELETE FROM dogs WHERE id=" . $_POST['removal_id']);
		DBConnector::makeQuery("DELETE FROM dog_images WHERE img_set=" . $_POST['removal_id']);
		$dogs = DBConnector::makeQuery("SELECT * FROM dogs WHERE type=" . $_POST['table_id']);
		$type = $_POST['table_id'];
	}
	
	if (isset($_GET['sex']) and is_numeric($_GET['sex']))
	{
		$sex = (int) $_GET['sex'];
		$dogs = DBConnector::makeQuery("SELECT * FROM dogs WHERE type=$type AND sex=$sex ORDER BY id DESC");
	}
	elseif(isset($_GET['training']) and is_numeric($_GET['training']))
	{
		$training = (int) $_GET['training'];
		$dogs = DBConnector::makeQuery("SELECT * FROM dogs WHERE type=$type AND training=$training ORDER BY id DESC");
	}
	else
	{
		$dogs = DBConnector::makeQuery("SELECT * FROM dogs WHERE type=$type ORDER BY id DESC");
	}
?>

<html>
	<head>
		<script type="text/javascript" src="js/jquery.js"></script>
		<link rel="stylesheet" type="text/css" href="css/admin-main.css">
		<title>Broadleaf Admin: Dogs</title>
		<script type="text/javascript">
			$(document).ready(function ()
			{	
			
				$("#close_output").click(function()
				{
					$("#output").slideUp("normal");
				});
				
				$(".remove_button").click(function()
				{
					$("#confirm_remove").slideUp("normal");
					var id = parseInt($(this).parents("tr").attr("id"));
					$("#confirm_remove").slideDown("normal");
					$("#removal_id").val(id);
				});
				
				$("#confirm_delete").click(function ()
				{
					$("#confirm_remove").slideUp("normal", function ()
					{
						$("#confirm_remove > form").submit();
					});
				});
				
				$("#cancel_delete").click(function()
				{
					$("#confirm_remove").slideUp("normal");
				});
				
			});
		</script>
	</head>
	<body>
		<div id="header"><h2>
		<?php 
			if ($type == 1) { echo "Studs &amp; Bitches";}
			elseif ($type == 2) { echo "Dogs For Sale";}
			elseif ($type == 3) { echo "Puppies";}
		?> 
		</h2></div>
		<div id="menu">
			<ul>
				<li><a <?php if ($type == 1) { echo "id=\"current\"";} ?> href="dogs.php?type=1">Studs &amp; Bitches</a></li>
				<li><a <?php if ($type == 2) { echo "id=\"current\"";} ?> href="dogs.php?type=2">Dogs For Sale</a></li>
				<li><a <?php if ($type == 3) { echo "id=\"current\"";} ?> href="dogs.php?type=3">Puppies</a></li>
				<li><a href="gallery.php">Gallery</a></li>
				<li><a href="info.php">Info</a></li>
				<li><a href="options.php">Settings</a></li>
				<li><a class="menu-right" href="logout.php">Log Out</a></li>
			</ul>
		</div>
		<div id="wrapper">
			<div id="output">
				<?php
				if (isset($_GET['success']) and is_numeric($_GET['success']))
				{
					$bool = (int) $_GET['success'];
					if ($bool == 0)
					{
						echo "<span>Database successfully altered!";
						echo "<input id=\"close_output\" type=\"button\" value=\"Close\"></input></span>";
					}
				}
				?>
			</div>
			<div id="confirm_remove">
				<span>Are you sure you wish to remove this dog from the database?</span>
				<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
					<input id="removal_id" type="hidden" name="removal_id" />
					<input id="table_id" type="hidden" name="table_id" value="<?php echo $type?>" />
					<input id="confirm_delete" type="button" value="Confirm"></input>
					<input id="cancel_delete" type="button" value="Cancel"></input>
				</form>
			</div>
			<div id="options">
				<div class="shortButton"><a href="adddog.php?type=<?php echo $type; ?>"><img src="css/images/add.png" alt="add" /></a></div>
				<?php
					if ($type != 3)
					{
				?>
				<a class="menu" href="<?php $_SERVER['PHP_SELF'];?>?type=<?php echo $type; ?>">Show All</a>
				<a class="menu" href="<?php $_SERVER['PHP_SELF'];?>?type=<?php echo $type; ?>&sex=1">Males Only</a>
				<a class="menu" href="<?php $_SERVER['PHP_SELF'];?>?type=<?php echo $type; ?>&sex=2">Females Only</a>
				<?php 
						if ($type == 2)
						{
				?>
				<a class="menu" href="<?php $_SERVER['PHP_SELF'];?>?type=<?php echo $type; ?>&training=2">Trained</a>
				<a class="menu" href="<?php $_SERVER['PHP_SELF'];?>?type=<?php echo $type; ?>&training=3">Untrained</a>
				<?php
						}
					}
				?>
			</div>
			<div id="query-results">
				<table>
					<tr><th><?php if ($type == 3) { ?>Title<?php } else { ?>Dog Name<?php } ?></th><?php if ($type != 3) { ?><th>Sex</th><th>Breed</th><?php if ($type == 2) { ?><th>Training</th><?php } }?><?php if($type == 3) {?><th>Due To Leave</th><th>Is Sold?</th><?php } ?><th></th><th></th></tr>
					<?php
						if (mysql_num_rows($dogs) > 0)
						{
							while ($row = mysql_fetch_array($dogs))
							{
								$dog_sex = mysql_fetch_array(DBConnector::makeQuery("SELECT sex FROM sex WHERE id=" . $row['sex']));
								$dog_breed = mysql_fetch_array(DBConnector::makeQuery("SELECT breed FROM breed WHERE id=" . $row['breed']));
								$dog_training = mysql_fetch_array(DBConnector::makeQuery("SELECT training FROM training WHERE id=" . $row['training']));
								
								echo "<tr id=\"" . $row['id'] . "_dog\">";
								echo "<td>" . $row['dog_name'] . "</td>";
								if ($type != 3)
								{
									echo "<td>" . $dog_sex['sex'] . "</td>";
									echo "<td>" . $dog_breed['breed'] . "</td>";
									if ($type == 2)
									{
										echo "<td>" . $dog_training['training'] . "</td>";									
									}
								}
								elseif ($type == 3)
								{
									echo "<td>" . $row['due_leave'] . "</td>";
									
									if ($row['is_sold'] == 0)
									{
										echo "<td>No</td>";
									}
									else
									{
										echo "<td>Yes</td>";
									}
									
								}
								echo "<td><a class=\"edit_button\" href=\"editdog.php?id=". $row['id']."&type=" .$type. " \"><img src=\"css/images/edit.png\" alt=\"Edit\" /></a></td>";
								echo "<td><a class=\"remove_button\" href=\"#\" ><img src=\"css/images/remove.png\" alt=\"Remove\" /></a></td>";
								echo "</tr>";
							}
						}
						else
						{
					?>
				</table>
				<?php
						echo "<span id=\"no-records\">There are no records to display</span>";
					}
				?>
			</div>
		</div>
	</body>
</html>