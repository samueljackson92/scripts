<?php get_header();?>
	<div id="content">
		<div id="blog">
		   <div id="header-img"><img src="<?php echo get_header_image() ?>" alt="header"/></div>
	<?php if (have_posts()) : ?>
	<?php while (have_posts()) : the_post(); ?>
			<div class="post">
				<h3 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h3>
				<small class="date"><?php the_time('l, F j, Y');?></small><br />
				<small class="comments"><?php comments_popup_link('0 comments');?></small>
				<div class="post-body">
				<?php the_content('Read More...');?>
				</div>
			</div>
	<?php endwhile; ?>
			<div class="navigation">
				<span class="previous-entries"><?php next_posts_link('<< Older Posts');?></span>
				<span class="next-entries"><?php previous_posts_link('Newer Posts >>');?></span>
			</div>
	<?php else : ?>
			<h2>Not Found</h2>
	<?php endif; ?>
		</div>
		<?php get_sidebar();?>
	</div>
	<div class="push"></div>
</div>
<?php get_footer(); ?>