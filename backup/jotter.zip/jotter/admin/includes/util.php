<?php
class Util {
	public static function clean_input($str) {
		if(!get_magic_quotes_gpc()) {
			$str = mysql_real_escape_string($str);
		}
		
		return $str;
	}
	
	public static function validate_email($email) {
		if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
			return true;
		}
		
		return false;
	}
}
?>