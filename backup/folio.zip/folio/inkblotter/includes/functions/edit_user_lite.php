<?php
	require_once('../access.php');
	require_once('../dbconnector.php');
	$db = new DataBase;
	  
	$db->makeConnection();

	$id = makeSafe($_POST['id']);
	$password = makeSafe($_POST['password']);
	$email = makeSafe($_POST['email']);
	$nickname = makeSafe($_POST['nickname']);
	  
	$user_current = mysql_fetch_array($db->makeQuery("SELECT * FROM cmsusers WHERE userid='$id'"));
	$salt = $user_current['unique_salt'];
		
	if ($password == NULL)
	{
		$password = $user_current['password'];
	}
	else
	{
		$password = sha1($salt . $password);
	}

	$queryStr = 'UPDATE cmsusers SET password="'.$password.'", user_nicename="'.$nickname.'", email="'.$email.'" WHERE userid="'.$id.'"';
	
	$db->makeQuery($queryStr);
	$db->closeConnection();
	
	function makeSafe($var)
	{
		return mysql_real_string(strip_tags($var));
	}
?>