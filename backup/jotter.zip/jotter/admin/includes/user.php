<?php
class User {
	private $user_name = "";
	private $user_id = "";
	private $nice_name = "";

	public function __construct($query) {
		$user_name = $query['user_name'];
		$user_id = $query['id'];
		$nice_name = $query['nice_name'];
	}
	public function get_name() {
		return $user_name;
	}
	public function get_id() {
		return $user_id;
	}
	public function get_nice_name() {
		return $nice_name;
	}
}
?>