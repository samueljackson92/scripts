<?php
	require_once('../access.php');
?>