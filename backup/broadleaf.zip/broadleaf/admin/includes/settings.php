<?php 
class ServerSettings
{
	public $settings;
	
	public static function getSettings()
	{	
		//database variables
		$settings['dbuser'] = 'root';
		$settings['dbpassword'] = 'fforde';
		$settings['dbhost'] = 'localhost';
		$settings['dbname'] = 'broadleaf';
		return $settings;
	}
}
?>