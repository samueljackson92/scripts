<?php
	class FileManager
	{	
		public static function uploadFile($file, $tmpfile, $targetpath)
		{
			if ( substr(basename($file), -3) == "jpg" ||
			substr(basename($file), -3) == "png" ||
			substr(basename($file), -3) == "gif")
			{
			
				if (!is_dir($targetpath)) 
				{
					mkdir($targetpath);
				}
				
				$targetpath = $targetpath . basename($file);
				
				if(!move_uploaded_file($tmpfile, $targetpath)) 
				{
					return false;
				}
				
				return true;
			}
			return false;
		}
		
		public static function removeDir($dir)
		{
			
		   if (is_dir($dir)) {
			 $objects = scandir($dir); 
			 foreach ($objects as $object) { 
			   if ($object != "." && $object != "..") { 
				 if (filetype($dir."/".$object) == "dir") removeDir($dir."/".$object); else unlink($dir."/".$object); 
			   } 
			 } 
			 reset($objects); 
			 rmdir($dir); 
		   } 
		}
		
		public static function removeFile($targetpath)
		{
			if (file_exists($targetpath))
			{
				return unlink($targetpath);
			}
		}
		
		public static function rename($target, $new)
		{
			if (file_exists($target) or is_dir($target))
			{
				return rename($target, $new);
			}
		}
	}
?>