<?php
	//require_once("../access.php");
	require_once("../settings.php");
	$settings = ServerSettings::getSettings();
	session_start();
	$dir = $settings['cmsdir'] . "/inkblotter/media/" . $_SESSION['currentdir'] . $_POST['name'];
	mkdir($dir, 0700);
?>