<?php
require("includes/access.php");
?>

<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/admin-main.css">
		<title>Broadleaf Admin: Main</title>
	</head>
	<body>
		<div id="header"><h2>Broadleaf Administration</h2></div>
		<div id="menu">
			<ul>
				<li><a href="dogs.php?type=1">Studs &amp; Bitches</a></li>
				<li><a href="dogs.php?type=2">Dogs For Sale</a></li>
				<li><a href="dogs.php?type=3">Puppies</a></li>
				<li><a href="gallery.php">Gallery</a></li>
				<li><a href="info.php">Info</a></li>
				<li><a href="options.php">Settings</a></li>
				<li><a class="menu-right" href="logout.php">Log Out</a></li>
			</ul>
		</div>
		<div id="wrapper">
			<div id="intro" >
				<p>Welcome back to the broadleaf administration system. You have successfully logged in as <?php echo $_SESSION['user'];?>.</p>
				
			</div>
		</div>
	</body>
</html>