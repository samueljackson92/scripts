<?php
session_start();

require("includes/access.php");
require("includes/dbconnector.php");
require("includes/util.php");

DBConnector::makeConnection();
$user = mysql_fetch_assoc(DBConnector::makeQuery("SELECT * FROM users WHERE username='" . $_SESSION['user'] . "'" ));

if (isset($_POST['new_login']))
{
	$new_name = $_POST['new_login'];
	$new_name = Util::cleanInput($new_name);
	
	DBConnector::makeQuery("UPDATE users SET username='$new_name' WHERE id=" . $user['id']);
	$_SESSION['user'] = $new_name;
	$success= 0;
}

if (isset($_POST['new_password']))
{
	$new_password = $_POST['new_password'];
	$new_password = Util::cleanInput($new_password);
	$new_password = Util::hashPassword($new_password, $user['salt']);

	DBConnector::makeQuery("UPDATE users SET password='$new_password' WHERE id=" . $user['id']);
	$success= 0;
}

DBConnector::closeConnection();
?>

<html>
	<head>
		<script type="text/javascript" src="js/jquery.js"></script>
		<link rel="stylesheet" type="text/css" href="css/admin-main.css">
		<link rel="stylesheet" type="text/css" href="css/admin-form.css">
		<title>Broadleaf Admin: Options</title>
		<script type="text/javascript">
			$(document).ready(function ()
			{
				$("#submit_login").click(function()
				{	
					flag = false;
					$("#error_output").show();
					$("#error_output").html("");
					
					if ($("#new_login").val() == "" || $("#new_login").val().length < 6 )
					{
						flag = true;
						$("#error_output").append("<span>You must enter a login name that is at least 6 characters long</span>");
					}
					
					if (!flag)
					{
						$("#edit_login").submit()
					}
				});				
				
				$("#submit_password").click(function()
				{	
					flag = false;
					$("#error_output").html("");
					
					if ($("#new_password").val() == "" || $("#new_password").val().length < 6)
					{
						flag = true;
						$("#error_output").append("<span>You must enter a password that is at least 6 characters long.</span></br>");
					}
					
					if ($("#new_password").val() != $("#new_password_confirm").val())
					{
						flag = true;
						$("#error_output").append("<span>Passwords do not match. Please ensure that they match.</span>");
					}
					
					if (!flag)
					{
						$("#edit_password").submit();
					}
					else
					{
						$("#error_output").show();
					}
				});
				
				$("#close_output").click(function()
				{
					$("#output").slideUp("normal");
				});
			});
		</script>
	</head>
	<body>
		<div id="header"><h2>Settings</h2></div>
		<div id="menu">
			<ul>
				<li><a href="dogs.php?type=1">Studs &amp; Bitches</a></li>
				<li><a href="dogs.php?type=2">Dogs For Sale</a></li>
				<li><a href="dogs.php?type=3">Puppies</a></li>
				<li><a href="gallery.php">Gallery</a></li>
				<li><a href="info.php">Info</a></li>
				<li><a id="current" href="options.php">Settings</a></li>
				<li><a class="menu-right" href="logout.php">Log Out</a></li>
			</ul>
		</div>
		<div id="wrapper">
			<div id="err">
				<div id="output">
					<?php
					if (isset($success) and is_numeric($success))
					{
						$bool = (int) $success;
						if ($bool == 0)
						{
							echo "<span>Database successfully altered!";
							echo "<input id=\"close_output\" type=\"button\" value=\"Close\"></input></span>";
						}
					}
					?>
				</div>
			</div>
			<div id="error_output">
			</div>
			<div id="editor">
				<form id="edit_login" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
					<fieldset>
						<label for="new_login">Change Login Name:</label>
						<input id="new_login" name="new_login" type="text" value="<?php echo $_SESSION['user']; ?>"/>
						<input id="submit_login" class="button" name="submit_login" type="button" value="Edit"/>
					</fieldset>
				</form>
				<form id="edit_password" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
					<fieldset>
						<label for="new_password">Change Password:</label>
						<input id="new_password" name="new_password" type="password" />
						<label for="new_password_confirm">Confirm New Password:</label>
						<input id="new_password_confirm" name="new_password_confirm" type="password" />
						<input id="submit_password" class="button" name="submit_password" type="button" value="Edit" />
					</fieldset>
				</form>
			</div>
		</div>
	</body>
</html>