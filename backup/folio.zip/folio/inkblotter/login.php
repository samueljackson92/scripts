<?php
	require_once("includes/errorlogger.php");
	
	session_start();
	$incorrect = false;
	$lockedout = false;
	
	if (isset($_COOKIE['logged_in_cms']) and isset($_SESSION['user']))
	{
		header("Location: index.php");
	}
	
	if (isset($_SESSION['loginfailed']))
	{
		if (time() > ($_SESSION['loginfailed'] + 300))  
		{ 
			unset($_SESSION['loginfailed']); 
			$_SESSION['loginattempts'] = 0;
			$lockedout = false;
		}
		else
		{
			$lockedout = true;
		}
	}
	
	else
	{
		if (isset($_POST['user']))
		{	
			if (!isset($_SESSION['loginattempts']))
			{
				$_SESSION['loginattempts'] = 0;
			}

			$_SESSION['loginattempts']++;
				
			$incorrect = true;
			require_once('includes/dbconnector.php');
			$db = new DataBase;
			$db->makeConnection();
			
			$user =  mysql_real_escape_string(strip_tags($_POST['user']));
			$pass =  mysql_real_escape_string(strip_tags($_POST['userpass']));
				
			$query = $db->makeQuery("SELECT * FROM cmsusers WHERE username='$user'");
			$num_rows = mysql_num_rows($query);
				
			if ($num_rows == 1)
			{
				$q = mysql_fetch_array($query);
				$pass_data = sha1($q['unique_salt'] . $pass); 
				if ($pass_data == $q['password'])
				{
					$incorrect = false;
					$_SESSION['user'] = $user;
					$_SESSION['active'] = true;
					unset($_SESSION['failedusernames']);
					unset($_SESSION['failedpasswords']);
					unset($_SESSION['failedhashes']);
					setcookie("logged_in_cms", $user, time()+3600);
					header("Location: index.php");
					exit;
				}
			}
				
			$_SESSION['failedusernames'] = $_SESSION['failedusernames'] . $user . "\n";
			$_SESSION['failedpasswords'] = $_SESSION['failedpasswords'] . $pass . "\n";
			$_SESSION['failedhashes'] = $_SESSION['failedhashes'] . $pass_data . "\n";
				
			if ($_SESSION['loginattempts'] == 3)
			{
				//dump a text file entry about the incident
				$_SESSION['loginfailed'] = time();
				$lockedout = true;
				
				$file = "logs/failedlogins.txt";
				$fh = fopen($file, 'a') or die(ErrorLog::throwFileException("Could not open file " . $file));
				$s = "----------------------------------------------------------------------------------\n";
				$s = $s . "FAILED LOGIN LOCKOUT\n";
				$s = $s . "----------------------------------------------------------------------------------\n";
				$s = $s . "Error Time: ". date('l jS \of F Y h:i:s A') . "\n";
				$s = $s . "Locked out IP:" . $_SERVER['REMOTE_ADDR'] . "\n";
				$s = $s . "Usernames Were:\n";
				$s = $s . $_SESSION['failedusernames'];
				$s = $s . "Passwords Were:\n";
				$s = $s . $_SESSION['failedpasswords'];
				$s = $s . "Hashes Were:\n";
				$s = $s . $_SESSION['failedhashes'];
				fwrite($fh, $s);
				fclose($fh);
					
				unset($_SESSION['failedusernames']);
				unset($_SESSION['failedpasswords']);
				unset($_SESSION['failedhashes']);
			}
		}
	}
?>
<html>
	<head>
    	<title>Login</title>
		<!-- CSS Imports -->
		<link type="text/css" rel="stylesheet" href="lib/styling/reset.css" />
		<link type="text/css" rel="stylesheet" href="lib/styling/masterstyle.css"  />
        <link rel="stylesheet" type="text/css" href="jquery-ui/development-bundle/themes/base/jquery.ui.core.css">
        <link rel="stylesheet" type="text/css" href="jquery-ui/development-bundle/themes/base/jquery.ui.theme.css">
        <link rel="stylesheet" type="text/css" href="jquery-ui/development-bundle/themes/base/jquery.ui.button.css">
		
		<!-- Javascript Imports -->
        <script type="text/javascript" src="jquery-ui/js/jquery-1.4.2.min.js"></script>
		<script type="text/javascript" src="jquery-ui/js/jquery-ui-1.8.2.custom.min.js"></script>
		<script type="text/javascript" src="jquery-ui/development-bundle/ui/jquery.ui.button.js"></script>
        <script type="text/javascript">
			$(document).ready(function()
			{
				$("#submit")
					.button({ icons: {primary:'ui-icon-key'}})
					.click(function()
							{
								$(this).parents("form").submit();
							});
			});
		</script>
	</head>
	<body>
		<div id="content-wrap">
			<div id="content">
                <div id="intro">
                	<div id="login">
                        <h3>Please Login</h3>
                        <?php
							if ($incorrect == true and $lockedout == false)
							{
								echo '<div id="error" class="ui-widget"> 
									  <div class="ui-state-error ui-corner-all" style="padding: 0 .7em;"> 
										<p>
										<span class="ui-icon ui-icon-alert" style="float: left; margin-right: .4em;">
										</span>
											Incorrect password or username. Please try again.
										</p>
									  </div> 
									  </div> ';
							}
							
							if ($lockedout == false)
							{
						?>
                        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="login">
                            <label for="user">Username</label>
                            <input id="username" name="user" type="text" value="">
                            <label for="userpass">Password</label>
                            <input id="userpass" name="userpass" type="password" value="">
                            <a id="submit" href="#">Login</a>
                        </form>
						<?php
							}
							else
							{
							?>
								<p>You have been locked out!</p>
						<?php
							}
						?>
                    </div>
                </div>
		  </div>
		</div>
	</body>
</html>