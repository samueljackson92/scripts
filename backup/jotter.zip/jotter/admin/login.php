<?php
	require_once('includes/auth.php');
	$user_auth = new Auth();
	
	if (isset($_GET['log_out'])) {
		Auth::log_out($_SERVER['PHP_SELF']);
	}
	
	if (isset($_POST['user_name']) && isset($_POST['password'])) {
		if($user_auth->connect_user($_POST['user_name'], $_POST['password'])) {
			$user_auth->auth_successful($_POST['user_name'], "index.php");
		}
		else
		{
			$user_auth->auth_failed($_SERVER['PHP_SELF'], 1);
		}
	}
?>
<html>
	<head>
		<title>Jotter</title>
		<link rel="stylesheet" href="css/general.css" type="text/css"></link>
		<link rel="stylesheet" href="css/form.css" type="text/css"></link>
		<script type="text/javascript" src="js/jquery-1.6.4.min.js"></script>
		<script type="text/javascript" src="js/form.js"></script>
		<script type="text/javascript" src="js/login.js"></script>
	</head>
	<body>
		<?php include ("includes/error.php"); ?>
		<form id="login_form" name="login_form" action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
			<label for="user_name">Username:</label><input class="textbox" id="user_name" name="user_name" type="text" />
			<label for="password">Password:</label><input class="textbox" id="password" name="password" type="password" />
			<input type="submit" id="submit" class="button" value="Login" />
		</form>
	</body>
</html>