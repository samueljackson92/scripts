<?php
define('HEADER_IMAGE', '%s/img/header.png');
define('HEADER_TEXTCOLOR', '');
define('HEADER_IMAGE_WIDTH', 600); // use width and height appropriate for your theme
define('HEADER_IMAGE_HEIGHT', 150);
define('NO_HEADER_TEXT', true );

// gets included in the site header
function header_style() {
    ?><style type="text/css">
        #header-img {
            background: url(<?php header_image(); ?>);
        }
    </style><?php
}

// gets included in the admin header
function admin_header_style() {
    ?><style type="text/css">
        #heading {
            width: <?php echo HEADER_IMAGE_WIDTH; ?>px;
            height: <?php echo HEADER_IMAGE_HEIGHT; ?>px;
            background: no-repeat;
        }
    </style><?php
}

add_custom_image_header('header_style', 'admin_header_style');

if ( function_exists('register_sidebar') )
    register_sidebar();
?>