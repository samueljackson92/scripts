<?php
	require_once("../access.php");
	require_once("../settings.php");
	$settings = ServerSettings::getSettings();
	session_start();
	$old = $settings['cmsdir'] . "/inkblotter/media/" . $_SESSION['currentdir'] . $_POST['old_name'];
	$new = $settings['cmsdir'] . "/inkblotter/media/" . $_SESSION['currentdir'] . $_POST['new_name'];
	rename($old, $new);
?>