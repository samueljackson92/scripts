<?php
	require_once('../access.php');
	require_once('../dbconnector.php');
	$id = $_POST["id"];
	$db = new DataBase;
	$db->makeConnection();
	$db->makeQuery("DELETE FROM cmsusers WHERE userid='". $id . "'");
	$db->closeConnection();
?>