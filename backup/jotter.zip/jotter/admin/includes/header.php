<div id="header">
	<h1>Jotter</h1>
</div>
<div id="sidebar">
	<ul>
		<li><a href="index.php">Posts</a></li>
		<li><a href="media.php">Media</a></li>
		<li><a href="login.php?log_out=true">Log Out</a></li>
	</ul>
</div>