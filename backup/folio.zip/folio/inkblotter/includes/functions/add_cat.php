<?php
	require_once('../access.php');
	require_once('../dbconnector.php');
	$db = new DataBase;
	$db->makeConnection();
	
	$cat_name = $_POST['cat_name'];
	
	$db->makeQuery("INSERT INTO cmscatagories (catindex, catagories) VALUES (NULL, '".$cat_name."')");
	
	$db->closeConnection();
?>