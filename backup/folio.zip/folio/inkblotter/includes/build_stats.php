<?php
require_once("access.php");
require_once("dbconnector.php");
$db = new DataBase;

$db->makeConnection();
$totalposts = mysql_num_rows($db->makeQuery("SELECT * FROM cmsarticles"));
$totalcats = mysql_num_rows($db->makeQuery("SELECT * FROM cmscatagories"));
$totalusers = mysql_num_rows($db->makeQuery("SELECT * FROM cmsusers"));

$q = $db->makeQuery("SELECT * FROM cmsarticles");

$monthposts = 0;
$yearposts = 0;

while($row = mysql_fetch_array($q))
{
	//do stuff with posts

	
	$date = $row['posttime'];
	preg_match("/([0-9]{2}th) | ([0-9]th)/", $date, $matches);
	$intdate = intval($matches[0]);
	preg_match("/(Jan|Feb)uary|Ma(rch|y)|April|Ju(ne|ly)|Augest|(Sept|Nov|Dec)ember|October/", $date, $matches);
	$month =  $matches[0];
	for($i=1;$i<=12;$i++)
	{ 
		if(date("F", mktime(0, 0, 0, $i, 1, 0)) == $month){ 
			$intmonth= $i; 
			break; 
		}
	}
	preg_match("/[0-9]{4}/", $date, $matches);
	$intyear = $matches[0];
	
	if (date("n") == $intmonth and date("Y") == $intyear)
	{
		$monthposts++;
	}
	
	if(date("Y") == $intyear)
	{
		$yearposts++;
	}
	
}

$q = $db->makeQuery("SELECT * FROM cmsusers");

$totaladmins = 0;
$totaleditors = 0;

while($row = mysql_fetch_array($q))
{	
	if ($row['level'] == 1)
	{
		$totaladmins++;
	}
	else
	{
		$totaleditors++;
	}
}


echo "<table>";
echo "<thead><tr><td>Post Statistics</td><td></td></tr></thead>";
echo "<tr><td># Posts in database:</td><td> $totalposts </td></tr>";
echo "<tr><td># Posts this month:</td><td> $monthposts </td></tr>";
echo "<tr><td># Posts this year:</td><td> $yearposts </td></tr>";
echo "</table>";

echo "<br />";

echo "<table>";
echo "<thead><tr><td>Catagory Statistics</td><td></td></tr></thead>";
echo "<tr><td># Catagories in database:</td><td> $totalcats </td></tr >";
echo "</table>";

echo "<br />";

echo "<table>";
echo "<thead><tr><td>User Statistics</td><td></td></tr></thead>";
echo "<tr><td># Users in database:</td><td> $totalusers </td></tr>";
echo "<tr><td># Admins:</td><td> $totaladmins </td></tr>";
echo "<tr><td># Editors:</td><td> $totaleditors </td></tr>";
echo "</table>";
?>