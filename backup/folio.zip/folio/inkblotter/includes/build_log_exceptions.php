<?php
	require("access.php");
	require_once("settings.php");
	$vars = ServerSettings::getSettings();

	$file = $vars['cmsdir']. "/inkblotter/logs/exceptions.txt";
	$fh = fopen($file, 'r') or die("can't open file");
	while($row = fgets($fh))
	{
		$logcontent = $logcontent . $row;
	}
	fclose($fh);
	
	echo "<h4>Site Exceptions Log File:</h4>";
	echo "<textarea rows=\"10\" cols=\"100\">";
	echo $logcontent;
	echo "</textarea>";
?>