<?php
require_once('../access.php');
require_once('../dbconnector.php');

$db = new DataBase;

$datetime = date('l jS \of F Y h:i:s A');
$db->makeQuery("INSERT INTO cmsarticles (ID, title, tagline, section, thearticle, posttime, edittime) 
VALUES (NULL, '".$_POST['title']."', '".$_POST['tagline']."', '".$_POST['cat']."', '".$_POST['text']."', '".$datetime."', '".$datetime."')");
	
$db->closeConnection();
?>