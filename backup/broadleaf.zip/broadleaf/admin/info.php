<?php
require("includes/access.php");
require("includes/dbconnector.php");

DBConnector::makeConnection();

if (isset($_POST['removal_id']) and is_numeric($_POST['removal_id']) and isset($_POST['table_id']))
{	
	$id = (int) $_POST['removal_id'];
	$table = $_POST['table_id'];
	if ($table == "misc")
	{
		DBConnector::makeQuery("DELETE FROM tabs WHERE id=$id");
	}
	elseif ($table == "health")
	{
		DBConnector::makeQuery("DELETE FROM health_tabs WHERE id=$id");
	}
}

$tabs = DBConnector::makeQuery("SELECT * FROM tabs");
$health_tabs = DBConnector::makeQuery("SELECT * FROM health_tabs");

?>

<html>
	<head>
		<script type="text/javascript" src="js/jquery.js" language="javascript"></script>
		<link rel="stylesheet" type="text/css" href="css/admin-main.css">
		<title>Broadleaf Admin: Main</title>
		<script type="text/javascript">
			$(document).ready(function ()
			{	
				$("#close_output").click(function()
				{
					$("#output").slideUp("normal");
				});
				
				$(".remove_button").click(function()
				{
					$("#confirm_remove").slideUp("normal");
					var id = parseInt($(this).parents("tr").attr("id"));
					var table = $(this).parents("table").attr("id");
					$("#confirm_remove").slideDown("normal");
					$("#removal_id").val(id);
					$("#table_id").val(table);
				});
				
				$("#confirm_delete").click(function ()
				{
					$("#confirm_remove").slideUp("normal", function ()
					{
						$("#confirm_remove > form").submit();
					});
				});
				
				$("#cancel_delete").click(function()
				{
					$("#confirm_remove").slideUp("normal");
				});
			});
		</script>
	</head>
	<body>
		<div id="header"><h2>Information</h2></div>
		<div id="menu">
			<ul>
				<li><a href="dogs.php?type=1">Studs &amp; Bitches</a></li>
				<li><a href="dogs.php?type=2">Dogs For Sale</a></li>
				<li><a href="dogs.php?type=3">Puppies</a></li>
				<li><a href="gallery.php">Gallery</a></li>
				<li><a id="current" href="info.php">Info</a></li>
				<li><a href="options.php">Settings</a></li>
				<li><a class="menu-right" href="logout.php">Log Out</a></li>
			</ul>
		</div>
		<div id="wrapper">
			<div id="output">
				<?php
				if (isset($_GET['success']) and is_numeric($_GET['success']))
				{
					$bool = (int) $_GET['success'];
					if ($bool == 0)
					{
						echo "<span>Database successfully altered!";
						echo "<input id=\"close_output\" type=\"button\" value=\"Close\"></input></span>";
					}
					elseif($bool == 1)
					{
						echo "<span>You cannot create anymore tabs!";
						echo "<input id=\"close_output\" type=\"button\" value=\"Close\"></input></span>";
					}
				}
				?>
			</div>
			<div id="confirm_remove">
				<span>Are you sure you wish to remove this dog from the database?</span>
				<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
					<input id="removal_id" type="hidden" name="removal_id" />
					<input id="table_id" type="hidden" name="table_id" />
					<input id="confirm_delete" type="button" value="Confirm"></input>
					<input id="cancel_delete" type="button" value="Cancel"></input>
				</form>
			</div>
			<div id="options">
				<div class="shortButton"><a href="addhealthinfo.php"><img src="css/images/add.png" alt="add" /></a></div>
			</div>
			<div id="query-results">
				<table id="health">
					<tr><th>Health Pages</th><th></th><th></th></tr>
					<?php
						if (mysql_num_rows($health_tabs) > 0)
						{
							while ($row = mysql_fetch_array($health_tabs))
							{
						?>
							<tr id="<?php echo $row['id']; ?>">
								<td>
								<?php echo html_entity_decode($row['title']);?>
								</td>
								<?php
								echo "<td><a class=\"edit_button\" href=\"edithealthinfo.php?id=". $row['id'] . "\"><img src=\"css/images/edit.png\" alt=\"Edit\" /></a></td>";
								echo "<td><a class=\"remove_button\" href=\"#\" ><img src=\"css/images/remove.png\" alt=\"Remove\" /></a></td>";
								?>
							</tr>
						<?php
							}
						}
						else
						{
					?>
				</table>
				<?php
						echo "<span id=\"no-records\">There are no records to display.</span>";
					}
				?>
				</table >
				<div id="options">
					<div class="shortButton"><a href="addinfo.php"><img src="css/images/add.png" alt="add" /></a></div>
				</div>
				<table id="misc">
					<tr><th>Misc Pages</th><th></th><th></th></tr>
					<?php
						if (mysql_num_rows($tabs) > 0)
						{
							while ($row = mysql_fetch_array($tabs))
							{
						?>
							<tr id="<?php echo $row['id']; ?>">
								<td>
								<?php echo html_entity_decode($row['title']);?>
								</td>
								<?php
								echo "<td><a class=\"edit_button\" href=\"editinfo.php?id=". $row['id'] . "\"><img src=\"css/images/edit.png\" alt=\"Edit\" /></a></td>";
								echo "<td><a class=\"remove_button\" href=\"#\" ><img src=\"css/images/remove.png\" alt=\"Remove\" /></a></td>";
								?>
							</tr>
						<?php
							}
						}
						else
						{
					?>
				</table>
				<?php
						echo "<span id=\"no-records\">There are no records to display.</span>";
					}
				?>
			</div>
		</div>
	</body>
</html>