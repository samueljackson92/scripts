<?php
	require_once('access.php');
	require_once('dbconnector.php');
	require_once('pagination.php');
	$db = new DataBase;
	$db->makeConnection();
	
	$per_page = 5; 
	if(isset($_POST))
	{
		$page = $_POST['page_count'];
	}
	
	$start = ($page)*$per_page;
	$query = $db->makeQuery("SELECT * FROM cmsusers LIMIT $start, $per_page");
	
	
	echo '<table><thead>';
	echo '<tr><td>User</td><td>Password</td><td>Security</td><td>E-Mail</td><td>Nickname</td><td>Edit</td><td>Delete</td></tr>';
	echo '</thead><tbody id="users_table">';
	
	while ($row = mysql_fetch_array($query))
	{
		$levelnum = $row['level'];
		$user_level = mysql_fetch_array($db->makeQuery("SELECT accesslevel FROM cmslevel WHERE levelindex='$levelnum'"));
			echo '<tr id="'. $row['userid'] .'">';
			echo '<td>' . $row['username'] . '</td>';
			echo '<td>' . $row['password'] . '</td>';
			echo '<td>' . $user_level['accesslevel'] . '</td>';
			echo '<td>' . $row['email'] . '</td>';
			echo '<td>' . $row['user_nicename'] . '</td>';
			echo '<td><a class="edit_user edit" href="#">Edit</a></td>';

			echo '<td>';
			if ($row['userid'] != 1)
			{
				echo '<a class="delete_user delete" href="#">Delete</a>';
			}
			echo '</td></tr>';;
	}
	
	echo '</tbody></table>';
	
	paginate('user', $per_page);
	
	$db->closeConnection();
?>