<?php
	require_once('../access.php');
	require_once('../dbconnector.php');
	$db = new DataBase;
	$db->makeConnection();
	
	if (isset($_POST['id']));
	{
		$id = $_POST['id'];
		$post = mysql_fetch_array($db->makeQuery("SELECT * FROM cmsarticles WHERE ID='$id'"));
	}
	
	$result = $db->makeQuery('SELECT * FROM cmscatagories');
	
	while ($row = mysql_fetch_array($result))
	{
		if ($row['catindex'] == $post['section'])
		{
			echo '<option value="'.$row['catindex'].'" selected="selected">'.$row['catagories'].'</option>';
		}
		else
		{
			echo '<option value="'.$row['catindex'].'">'.$row['catagories'].'</option>';
		}
	}
	
	echo $post['id'];
	
	$db->closeConnection();
?>