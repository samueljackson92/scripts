<html>
	<head>
		<title><?php bloginfo('name');?></title>
		<!--<script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
		<script language="javascript" src="js/shCore.js"></script>
		<script language="javascript" src="js/shBrushJava.js"></script>
		<script language="javascript" src="js/shBrushSql.js"></script>
		<link type="text/css" rel="stylesheet" href="css/SyntaxHighlighter.css"></link>-->
		
		<!--[if !IE 7]>
			<style type="text/css">
				#content-wrap {display:table;height:100%}
			</style>
		<![endif]-->
		<link type="text/css" rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>"></link>
	</head>
	<?php wp_head();?>
	<body>
		<div id="header">
			<div id="header-content"> 
				<h5><a href="<?php echo get_option('home'); ?>"><?php bloginfo('name'); ?></a></h5>
				<div id="pages">
					<ul>
						<?php wp_list_pages('sort_column=menu_order&depth=1&title_li=');?>
					</ul>
				</div>
			</div>
		</div>