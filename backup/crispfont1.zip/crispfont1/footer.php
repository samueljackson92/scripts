 <?php wp_footer(); ?> 		<div id="footer">
			<h5 id="copyright">Copyright &copy; <?php echo date('Y');?> Samuel Jackson. All Rights Reserved. <br />Powered By <a href="http://wordpress.org/" >Wordpress</a> <?php  echo get_bloginfo('version'); ?></h5>
		</div>
	</body>
		<!--<script language="javascript">
			window.onload = function () {
				dp.SyntaxHighlighter.ClipboardSwf = '/flash/clipboard.swf';
				dp.SyntaxHighlighter.HighlightAll('code');
			}
		</script>-->
</html>