<?php
final class ErrorEnums {
	const LOGIN_AUTH_ERROR = 1;
}
?>