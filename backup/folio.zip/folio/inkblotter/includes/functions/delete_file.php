<?php
	session_start();
	require_once("../access.php");
	require_once("../settings.php");
	$settings = ServerSettings::getSettings();
	$dir = $settings['cmsdir'];
	
	$file = $_POST['id'];
	$file = $dir . "/inkblotter/media/" . $_SESSION['currentdir'] . $file;
	unlink($file);
?>