<?php
	require_once("includes/settings.php");
	$settings = ServerSettings::getSettings();
	$addr = "Location: http://" . $settings['siteaddr'];
	header($addr);
?>