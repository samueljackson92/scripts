<?php
	require_once('../access.php');
	require_once('../dbconnector.php');
	$id = $_POST["id"];
	$db = new DataBase;
	$db->makeQuery("DELETE FROM cmsarticles WHERE ID='". $id . "'");
	$db->closeConnection();
?>