<?php
require_once('settings.php');
require_once("errorlogger.php");
class DataBase 
{	
	 public function __construct() {
			$this->makeConnection();
	 }
	public static function makeConnection ()
	{
		$settings = ServerSettings::getSettings();
		
		$con = mysql_connect($settings['dbhost'], $settings['dbuser'], $settings['dbpassword']);
		
		if (!$con)
		{
			die(ErrorLog::throwQueryException(mysql_error()));
		}
		
		mysql_select_db($settings['dbname'], $con) or die(ErrorLog::throwQueryException(mysql_error()));
	}
	
	public static function makeQuery ($query)
	{
		$result = mysql_query($query) or die(ErrorLog::throwQueryException(mysql_error()));
		return $result;
	}
	
	public static function closeConnection ()
	{
		$result = mysql_close() or die(ErrorLog::throwQueryException(mysql_error()));
		return $result;
	}
}
?>