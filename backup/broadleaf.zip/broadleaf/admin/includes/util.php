<?php
class Util
{
	public static function cleanInput($str)
	{
		$str = mysql_real_escape_string(htmlentities(utf8_encode($str)));
		return $str;
	}
	
	public static function hashPassword($pass, $salt)
	{
		$pass = sha1($pass . $salt);
		return $pass;
	}
	
}
?>