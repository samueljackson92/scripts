<?php
	require_once("access.php");
	require_once("settings.php");

	session_start();
	$settings = ServerSettings::getSettings();
	$dir = $settings['cmsdir'];

	if (isset($_POST['opendir']))
	{
		if (!preg_match("/\/$/",$_SESSION['currentdir'])) 
		{
			$_SESSION['currentdir']= $_SESSION['currentdir'] . "/";
		}
		$_SESSION['currentdir'] = $_SESSION['currentdir'] .  $_POST['opendir'] . "/";
		$dir = $dir . "/inkblotter/media" . $_SESSION['currentdir'];
		$dirh = opendir($dir);
		unset($_POST['opendir']);
		if ($_SESSION['currentdir'] == "/")
		{
			unset ($_SESSION['currentdir']);
		}
	}
	elseif(isset($_POST['updir']))
	{
		$matches = preg_split("/\//",$_SESSION['currentdir']);
		array_pop($matches);
		array_pop($matches);
		$_SESSION['currentdir'] = implode("/",$matches);
		$dir = $dir . "/inkblotter/media" . $_SESSION['currentdir'];
		$dirh = opendir($dir);
		unset($_POST['updir']);
		if ($_SESSION['currentdir'] == "/")
		{
			unset ($_SESSION['currentdir']);
		}
	}
	else
	{
		$dir = $dir . "/inkblotter/media" . $_SESSION['currentdir'];
		$dirh = opendir($dir);
		if ($_SESSION['currentdir'] == "/")
		{
			unset ($_SESSION['currentdir']);
		}
	}
	
	while($entry = readdir($dirh))
	{
		if(substr($entry, 0, 1) != ".")
		{
			$dirEntries[] = $entry;
		}
	}
	
	closedir($dirh);

	$chunks = explode("/inkblotter", $dir);
	$dir = "../inkblotter" . $chunks[1];
	$dirfull = ".." . 	$chunks[1];
	
	if (!preg_match("/\/$/",$dirfull))
	{
		$dirfull = $dirfull . "/"; 
		$dir = $dir . "/";
	}
	
			
	echo "<br />";
	echo "<h4>CurrentDirectory: $dirfull</h4>";
			
	echo "<table>";
	echo "<thead><td>Filename</td><td></td><td>Type</td><td>File Size</td><td>Edit</td><td>Delete</td></thead>";

	if ($dirEntries == null) 
	{
		echo "</table>";
		echo "<p>Empty Directory</p>";
	}
	else
	{
		sort($dirEntries);
		
		for($i = 0; $i < count($dirEntries); $i++)
		{
			echo "<tr id=" . $dirEntries[$i] . ">";
			echo "<td>$dirEntries[$i]</td>";
			if (filetype($dirfull . $dirEntries[$i]) == "file")
			{
				echo "<td><a class=\"button view_file\" href=" . $dir . $dirEntries[$i] . ">View</a></td>";
				echo "<td>" . filetype($dirfull . $dirEntries[$i]). "</td>";
				echo "<td>" . format_bytes(filesize($dirfull . $dirEntries[$i])). "</td>";
				echo "<td><a class=\"edit_file delete\" href=\"#\">Edit</a></td>";
				echo "<td><a class=\"delete_file delete\" href=\"#\">Delete</a></td>";
			}
			elseif (filetype($dirfull . $dirEntries[$i]) == "dir")
			{
				echo "<td><a class=\"button open_dir\">Open</a></td>";
				echo "<td>" . filetype($dirfull . $dirEntries[$i]). "</td>";
				echo "<td> - </td>";
				echo "<td><a class=\"edit_file delete\" href=\"#\">Edit</a></td>";
				echo "<td><a class=\"delete_dir delete\" href=\"#\">Delete</a></td>";
			}
				echo "</tr>";
		}

		echo "</table>";
	}

	//function from the filesize() php man page
	function format_bytes($size) {
		$units = array(' B', ' KB', ' MB', ' GB', ' TB');
		for ($i = 0; $size >= 1024 && $i < 4; $i++) $size /= 1024;
		return round($size, 2).$units[$i];
	}
?>