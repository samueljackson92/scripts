<?php
	require_once('../access.php');
	require_once('../dbconnector.php');
	$db = new DataBase;
	$db->makeConnection();
	$db->makeQuery("DELETE FROM cmscatagories WHERE catindex='". $_POST["id"] . "'");
	$db->closeConnection();
?>