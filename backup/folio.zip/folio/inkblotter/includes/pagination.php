<?php
//pagination function

function paginate ($table, $per_page)
{

		require_once('dbconnector.php');
		$db = new DataBase;
		
		//select table
		if ($table == 'posts')
		{
			$sql_table = 'cmsarticles';
		}
		else if ($table == 'cat')
		{
			$sql_table = 'cmscatagories';
		}
		elseif ($table == 'user')
		{
			$sql_table = 'cmsusers';	
		}
		
		//count records, calculate number of pages needed
		$count_records = mysql_num_rows($db->makeQuery("SELECT * FROM $sql_table"));
		$pages = ceil($count_records/$per_page);

		//paginate
		echo "<div id='".$table."_pagination' class='pagination'><ul>";

			  for($i = 1; $i <= $pages; $i++)
			  {
				  echo "<li><a id='".($i -1)."_".$table."' href='#'>".$i ."</a></li>";
			  }

		 echo '</ul></div>';
}
?>