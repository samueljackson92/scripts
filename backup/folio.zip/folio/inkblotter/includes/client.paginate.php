<?php
	require_once("dbconnector.php");
	$db = new DataBase;
	
	$id = $_POST['page_id'];
	$per_page = 2;
	$start = $id * $per_page;
	
	$q = "SELECT * FROM cmsarticles ORDER BY ID DESC LIMIT $start, $per_page";
	$q =	$db->makeQuery($q);
	
	while ($post = mysql_fetch_array($q))
	{
		echo '<div id="post-' . $post['ID'] . '"  class="project">';
		echo '<h2 class="title">' . $post['title'] . '</h2>';
		echo '<small><i>Created: </i>' . $post ['posttime'] . '</small><br />';
		echo '<small><i>Last Edited: </i>' . $post ['edittime'] . '</small>';
		echo '<div class="intro">' . $post['thearticle'] . '</div>';
		echo "</div>";
	}

?>