<?php
	require_once('../access.php');
	require_once('../dbconnector.php');
	$db = new DataBase;
	
	$db->makeConnection();
	
	$id = makeSafe($_POST['id']);
	
	$user_current = mysql_fetch_array($db->makeQuery("SELECT * FROM cmsusers WHERE userid='$id'"));
	$username = makeSafe($_POST['username']);
	$password = makeSafe($_POST['password']);
	
	if ($id == 1)
	{
		$access_level = 1;
	}
	else
	{
		$access_level = makeSafe($_POST['access']);
	}
	$email = makeSafe($_POST['email']);
	$nickname = makeSafe($_POST['nickname']);
	$salt = $user_current['unique_salt'];
	
	if ($password == NULL)
	{
		$password = $user_current['password'];
	}
	else
	{
		$password = sha1($salt . $password);
	}

	$queryStr = 'UPDATE cmsusers SET username="'.$username.'", password="'.$password.'", user_nicename="'.$nickname.'", email="'.$email.'", level="'.$access_level.'" WHERE userid="'.$id.'"';
  
	$db->makeQuery($queryStr);
	$db->closeConnection();
	
	function makeSafe($var)
	{
		return mysql_real_string(strip_tags($var));
	}
?>