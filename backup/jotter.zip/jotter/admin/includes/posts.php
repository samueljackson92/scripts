<?php
require_once ('dbconnector.php');
require_once ('util.php');
class Posts {
	public static function getPosts() {
	}
	
	public static function addPost($args) {
		$name = Util::clean_input($args['title']);
		$text = Util::clean_input($args['text']);
		DBConnector::make_query("INSERT");
	}
	
	public static function editPost() {
	}
	
	public static function removePost() {
	}
}
?>