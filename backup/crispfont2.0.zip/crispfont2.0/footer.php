 <?php wp_footer(); ?> 		
		<div id="footer">
			<div id="footer-content">
				<h5 id="copyright">Copyright &copy; <?php echo date('Y');?> Samuel Jackson. All Rights Reserved. <br />Powered By <a href="http://wordpress.org/" >Wordpress</a> <?php  echo get_bloginfo('version'); ?></h5>
				<div id="valid_code">
					<a href="http://validator.w3.org/check?uri=referer" ><img src="<?php bloginfo('template_directory'); ?>/images/w3c_xhtml11_valid.png" alt="Validate XHTML" /></a>
					<a href="http://jigsaw.w3.org/css-validator/check/referer" ><img src="<?php bloginfo('template_directory'); ?>/images/w3c_css_valid.png" alt="Validate CSS" /></a>
				</div>
			</div>
		</div>
	</body>
</html>