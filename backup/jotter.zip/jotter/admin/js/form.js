function highlightField(elem) {
	elem.addClass("error_field");
}

function validateEmail(email) {
    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    if( !emailReg.test(email) || email == "" ) {
        return false;
    }
	return true;
}

function validateTextbox(txtBox) {
	if (txtBox == "") {
		return false;
	} 
	return true;
}