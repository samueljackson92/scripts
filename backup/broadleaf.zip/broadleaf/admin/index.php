<?php

session_start();
require("includes/dbconnector.php");
require("includes/util.php");

if (isset($_SESSION['logged_in']) and isset($_COOKIE['logged_in_cms']))
{
	header("Location: main.php");
	exit;
}

if (isset($_GET['error']) and is_string($_GET['error']))
{
	$error = $_GET['error'];
	if ($error == "unauthorised")
	{
		$errorstr = "You have been logged out due to unauthorised access.";
	}
	elseif ($error == "timeout")
	{
		$errorstr = "You have been logged out due to 30 minutes of inactivity.";
	}
}

if (isset($_POST['username']))
{
	DBConnector::makeConnection();
	$error = true;
	$user = Util::cleanInput($_POST['username']);
	$pass = Util::cleanInput($_POST['password']);
	
	$query = DBConnector::makeQuery("SELECT * FROM users WHERE username='$user'");
	
	if (mysql_num_rows($query) == 1)
	{
		$userdata = mysql_fetch_array($query);
		$pass = Util::hashPassword($pass, $userdata['salt']);
		if ($user == $userdata['username'] && $pass == $userdata['password'])
		{
			$error = false;
			$_SESSION['logged_in'] = true;
			$_SESSION['user'] = $user;
			setcookie("logged_in_cms", $user, time()+1800);
			header("Location: main.php");
			exit;
		}
	}
	
	DBConnector::closeConnection();
}

?>

<html>
	<head>
		<title>Broadleaf Administration Login</title>
		<link rel="stylesheet" type="text/css" href="css/admin-main.css">
		<link rel="stylesheet" type="text/css" href="css/admin-form.css">
		<title>Broadleaf Admin: Login</title>
		<style type="text/css">
			form input, form fieldset {width: inherit; padding: 5px; margin: 10px;}
			<?php
			if (isset($errorstr) or $error == true)
			{
			?>
			#error_output {display: block; width: 600px;}
			<?php
			}
			?>
		</style>
	</head>
	<body>
		<div id="header"><h2>Broadleaf Administration</h2></div>
		<div id="wrapper">
			<div id="err">
				<div id="error_output">
					<?php if (isset($errorstr)) {?><span><?php echo $errorstr; ?></span><?php }?>
					<?php if ($error === true) {echo "<span>Invalid login details, please try again.</span>";} ?>
				</div>
			</div>
			<div id="login">
				<form  method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
					<fieldset>
						<legend>Please Login:</legend>
						<label for="username">Username:</label>
						<input name="username" type="text"/><br />			
						<label for="password">Password:</label><br />
						<input name="password" type="password"/>
						<input class="button" name="submit" type="submit" value="Login"/>
					</fieldset>
				</form>
			</div>
		</div>
	</body>
</html>