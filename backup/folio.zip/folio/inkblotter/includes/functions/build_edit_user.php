<?php
	require_once('../access.php');
	require_once('../dbconnector.php');
	$db = new DataBase;
	$db->makeConnection();
	
	$id = $_POST['id'];
	
	$user = mysql_fetch_array($db->makeQuery("SELECT * FROM cmsusers WHERE userid='$id'"));
	$db->closeConnection();
	
   echo '<h5>Username:</h5>';
   echo '<input class="form_small" id="edit_user_username" name="username" type="text" value="'.$user['username'].'">';
   echo '<div class="ui-widget alert_password"><div class="ui-state-highlight ui-corner-all" style="padding: 0 .7em;">
   			<p><span class="ui-icon ui-icon-info" style="float: left; margin-right: .4em;"></span>
			Passwords Do Not Match!</p></div></div>';
   echo '<p>Changing your password is optional, Leave the following two fields blank to keep your current password.</p>';
   echo '<h5>New Password:</h5>';
   echo '<input class="form_small" id="edit_user_password_new" name="user_password_new" type="password" value="">';
   echo '<h5>New Password Confirm:</h5>';
   echo '<input class="form_small" id="edit_user_password_confirm" name="user_password_confirm" type="password" value="">';
   echo '<h5>Nickname:</h5>';
   echo '<input class="form_small" id="edit_user_nickname" name="user_nickname" type="text" value="'.$user['user_nicename'].'">';
   echo '<h5>Email:</h5>';
   echo '<input class="form_small" id="edit_user_email" name="user_email" type="text" value="'.$user['email'].'">';
   if ($id != 1)
   {
	   echo '<h5>Security Level:</h5>';
	   echo '<select id="edit_user_access" name="user_access"></select>';
	}
?>