<?php
	if (isset($_GET['error']) && is_numeric($_GET['error'])) {
?>
<div id="error">
<p>
<?php
		switch ((int) $_GET['error']) {
			case 1:
				echo "Incorrect Username or password";
				break;
			default:
				echo "An Unknown Error Occoured";
				break;
		}
?>
</p>
</div>
<?php
	}
?>