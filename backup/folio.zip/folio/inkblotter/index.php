<?php
	//redirect if login cookie not set
	session_start();
	if (!isset($_COOKIE['logged_in_cms']) or !isset($_SESSION['user']))
	{
		header("Location: login.php");
	}
	
	require_once('includes/dbconnector.php');
	$db = new DataBase;
	
	//code for access levels
	$user = $_SESSION['user'];
	$user_info = mysql_fetch_array($db->makeQuery("SELECT * FROM cmsusers WHERE username='$user'"));
	$levelnum = $user_info['level'];
	$user_level = mysql_fetch_array($db->makeQuery("SELECT accesslevel FROM cmslevel WHERE levelindex='$levelnum'"));
	$user_level = $user_level['accesslevel'];
?>
<html>
	<head>
    	<title>Inkblotter: CMS</title>
		<!-- CSS Imports -->
		<link type="text/css" rel="stylesheet" href="lib/styling/reset.css" />
		<link type="text/css" rel="stylesheet" href="lib/styling/masterstyle.css"  />
        
        <link rel="stylesheet" type="text/css" href="jquery-ui/development-bundle/themes/base/jquery.ui.dialog.css">
        <link rel="stylesheet" type="text/css" href="jquery-ui/development-bundle/themes/base/jquery.ui.core.css">
        <link rel="stylesheet" type="text/css" href="jquery-ui/development-bundle/themes/base/jquery.ui.theme.css">
        <link rel="stylesheet" type="text/css" href="jquery-ui/development-bundle/themes/base/jquery.ui.button.css">
        <link rel="stylesheet" type="text/css" href="jquery-ui/development-bundle/themes/base/jquery.ui.tabs.css">
        
		<!-- Javascript Imports -->     
        <script type="text/javascript" src="jquery-ui/js/jquery-1.4.2.min.js"></script>
        <script type="text/javascript" src="jquery-ui/js/jquery-ui-1.8.2.custom.min.js"></script>
        <script type="text/javascript" src="jquery-ui/development-bundle/ui/jquery.ui.dialog.js"></script>
        <script type="text/javascript" src="jquery-ui/development-bundle/ui/jquery.ui.button.js"></script>
        <script type="text/javascript" src="jquery-ui/development-bundle/ui/jquery.ui.tabs.js"></script>
        <script type="text/javascript" src="jquery-ui/development-bundle/ui/jquery.effects.fold.js"></script>
		<script type="text/javascript" src="lib/editor.js"></script>
</head>
	<body>
		<div id="content-wrap">
			<div id="content">
				<div id="intro">
                    <div id="userdata">
                    	<p><strong>Logged in as: </strong><i><span id="user_nicename"><?php echo $user_info['user_nicename']; ?> </span></i><strong>User ID: </strong><i><span id="user_id"><?php echo $user_info['userid']; ?> </span></i><strong>Access Level: </strong><i><span id="accesslevel"><?php echo $user_level; ?></span></i></p>
                    </div>
                    <a id="log_out" href="log_out.php">Log Out</a>
                    <a id="user_edit_info">Edit Account</a>
                    <a id="view_site" href="view_site.php">View Site</a>
				</div><!-- intro -->
                <div id="menu_panel">
					<ul>
						<li><a href="#tabs-1">Welcome</a></li>
						<li><a href="#tabs-2">Posts</a></li>
						<li><a href="#tabs-3">Catagories</a></li>
                        <li><a href="#tabs-4">Media</a></li>
                        <li><a href="#tabs-5">Stats</a></li>
                        <li><a href="#tabs-6">Users</a></li>
                        <li><a href="#tabs-7">logs</a></li>
					</ul>
					<div id="tabs-1" class="tabcontent">
						<div id="welcome">
							<h4>Welcome to Inkblotter</h4>
							<p>Welcome to Inkblotter content management system. You are currently running an early Alpha version of Inkblotter, which means it is currently under heavy development and new features are being added and tested all the time.</p>
						</div>
					</div><!--tabs-1 close-->
					<div id="tabs-2" class="tabcontent">
                    	<div id="sub_menu">
                            <a class="button add" id="add_post" href="#">Add</a>
                            <a class="button reload" id="reload_posts" href="#">Reload</a>
                      	</div>
                        <div id="editable_posts">
                        </div><!--Editable posts close-->
                	</div><!--tabs-1 close-->
                    <div id="tabs-3" class="tabcontent">
                        <div id="sub_menu">
                            <a class="button add add_cat" href="#">Add</a>
                            <a class="button reload" id="reload_cat" href="#">Reload</a>
                        </div>
                    	<div id="editable_cat">
                        </div><!--Editable catagories close-->
                	</div><!--tabs-2 close-->
                    <div id="tabs-4" class="tabcontent">
					    <div id="sub_menu">
                        </div>
						<div id="uploader">
							<div id="sub_menu">
								<a class="button add" id="add_file" href="#">Upload</a>
								<a class="button add" id="add_directory" href="#">Add Directory</a>
								<a class="button" id="up_directory" href="#">Up Directory</a>
								<a class="button reload" id="reload_media" href="#">Reload</a>

							</div>
							<div id="media">
							</div>
						</div>
                	</div><!--tabs-3 close-->
					<div id="tabs-5" class="tabcontent">
						<div id="sub_menu">
                            <a class="button reload" id="reload_stats" href="#">Reload</a>
                        </div>
						<div id="stats">
						</div>
					</div><!--tabs-4 close-->
					<div id="tabs-6" class="tabcontent">
						    <?php
								if ($levelnum == 1)
									{
							?>
                        <div id="sub_menu">
                            <a class="button add" id="add_user" href="#">Add</a>
                            <a class="button reload" id="reload_users" href="#">Reload</a>
                        </div>
                    	<div id="editable_user">
                        </div><!--Editable users close-->
                        <?php } ?>
					</div><!--tabs-5 close-->
					<div id="tabs-7" class="tabcontent">
						<div id="logs_logins">
						</div>
						<div id="sub_menu">
							<a class="button delete_log" id="delete_log_login" href="#">Clear Log</a>
							<a class="button reload" id="reload_log_login" href="#">Reload</a>
                        </div>
						<div id="logs_exceptions">
						</div>
						<div id="sub_menu">
							<a class="button delete_log" id="delete_log_exceptions" href="#">Clear Log</a>
							<a class="button reload" id="reload_log_exceptions" href="#">Reload</a>
                        </div>
					</div><!--tabs-5 close-->
                  <img id="loading_img" src="lib/images/ajax-loader.gif" width="220" height="19" alt="loading...">
                </div>
			</div>
		</div>
	</body>
</html>