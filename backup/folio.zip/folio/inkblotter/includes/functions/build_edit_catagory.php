<?php
	require_once('../access.php');
	require_once('../dbconnector.php');
	$id = $_POST['id'];
	
    $db = new DataBase;
	$db->makeConnection();
	
	$cat = mysql_fetch_array($db->makeQuery('SELECT catagories FROM cmscatagories WHERE catindex=' . $id));
	$db->closeConnection();
	
	echo '<h5>Catagory Name</h5><input class="form_small" id="edit_cat" name="edit_cat" type="text" value="'. $cat['catagories'] .'">'
?>