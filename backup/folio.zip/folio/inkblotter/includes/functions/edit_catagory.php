<?php
	require_once('../access.php');
	require_once('../dbconnector.php');
	$db = new DataBase;
	
	$db->makeConnection();

	$id = $_POST['id'];
	$cat = $_POST['cat'];
	
	$db->makeQuery('UPDATE cmscatagories 
				   SET catagories="'.$cat.'"
				   WHERE catindex="'.$id.'"');
	
	$db->closeConnection();
?>