<?php
require_once('settings.php');
class DBConnector
{	
	 public function __construct() {
			$this->makeConnection();
	 }
	public static function makeConnection ()
	{
		$settings = ServerSettings::getSettings();
		
		$con = mysql_connect($settings['dbhost'], $settings['dbuser'], $settings['dbpassword']);
		
		if (!$con)
		{
			die(mysql_error());
		}
		
		mysql_select_db($settings['dbname'], $con) or die(mysql_error());
	}
	
	public static function makeQuery ($query)
	{
		$result = mysql_query($query) or die(mysql_error());
		return $result;
	}
	
	public static function closeConnection ()
	{
		$result = mysql_close() or die(mysql_error());
		return $result;
	}
}
?>