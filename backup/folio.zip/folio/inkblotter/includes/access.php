<?php
session_start();
if ((strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') or ($_SESSION['active'] !=  true)) 
{
	header('HTTP/1.0 403 access denied');
	exit;
}
?>