$(document).ready(function () {
	$('#login_form').submit(function () {
		var error = false;
		
		if (!validateEmail($('#user_name').val())) {
			highlightField($('#user_name'));
			error = true;
		}
		
		if (!validateTextbox($('#password').val())) {
			highlightField($('#password'));
			error = true;
		}
		
		if (error) {
			return false;
		}
		
	});
});