<?php

class Error
{
	public $errorvars;
	
	public function buildError($ty, $ti, $t, $tx)
	{
		$errorvars['type'] = $ty;
		$errorvars['typeindex'] = $ti;
		$errorvars['time'] = $t;
		$errorvars['text'] = $tx;
		return $errorvars;
	}
}

class ErrorLog
{
	private function buildException($typeindex, $exec)
	{	
		if($typeindex == 0)
		{
			$type = "Unknown";
		}
		elseif ($typeindex == 1)
		{
			$type = "Query";
		}
		elseif ($typeindex == 2)
		{
			$type = "Directory";
		}
		elseif ($typeindex == 3)
		{
			$type = "File";
		}
		elseif ($typeindex == 4)
		{
			$type = "Upload";
		}
		else
		{
			$type = "Unknown";
		}
		
		$time = date("l dS \of F Y h:i:s A");
		$text = $type . " Exception: " . $exec;
		$error = new Error();
		return $error->buildError($type, $typeindex, $time, $text);
	}
	
	private function logException($error)
	{
				require_once("settings.php");
				$settings = ServerSettings::getSettings();
				$file = $settings['cmsdir'] . "/inkblotter/logs/exceptions.txt";
				$fh = fopen($file, 'a') or die("Can't open log file");
				$s = "----------------------------------------------------------------------------------\n";
				$s = $s . "EXCEPTION REPORT\n";
				$s = $s . "----------------------------------------------------------------------------------\n";
				$s = $s . "Error Type Index: " . $error['typeindex'] . "\n";
				$s = $s . "Error Type: " . $error['type'] . "\n";
				$s = $s . "Error Time: " . $error['time'] . "\n";
				$s = $s . "Error Report: \n";
				$s = $s . $error['text'] . "\n";
				fwrite($fh, $s);
				fclose($fh);
	}
	
	public static function throwException($exec)
	{
		$error = self::buildException(0, $exec);
		self::logException($error);
	}
	
	public static function throwQueryException($exec)
	{
		$error = self::buildException(1, $exec);
		self::logException($error);
	}
	
	public static function throwDirException($exec)
	{
		$error = self::buildException(2, $exec);
		self::logException($error);
	}
	
	public static function throwFileException($exec)
	{
		$error = self::buildException(3, $exec);
		self::logException($error);
	}
	
	public static function throwUploadException($exec)
	{
		$error = self::buildException(4, $exec);
		self::logException($error);
	}
	
}
?>