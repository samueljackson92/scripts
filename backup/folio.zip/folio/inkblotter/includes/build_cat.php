<?php
	require_once('access.php');
	require_once('dbconnector.php');
	require_once('pagination.php');
	$db = new DataBase;
	
	$per_page = 5; 
	if(isset($_POST))
	{
		$page = $_POST['page_count'];
	}
	
	$start = ($page)*$per_page;
	$query = $db->makeQuery("SELECT * FROM cmscatagories LIMIT $start, $per_page");
	
	echo '<table><thead><tr><td>Name</td><td>Edit</td><td>Delete</td> </tr><thead><tbody id="cat_table">';
	
	//for the uncatagorized catagory
	$row = mysql_fetch_array($query);
		
	while ($row = mysql_fetch_array($query))
	{
		echo '<tr id="'. $row['catindex'] .'"><td>' . $row['catagories'] . '</td>';
		echo '<td><a class="edit_cat edit" href="#">Edit</a></td>';
		echo '<td><a class="delete_cat delete" href="#">Delete</a></td></tr>';
	}
	
	echo '</tbody></table>';
	
	paginate('cat', $per_page);
	
	$db->closeConnection();
?>