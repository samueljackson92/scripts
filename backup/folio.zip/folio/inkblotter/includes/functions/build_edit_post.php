<?php
	require_once('../access.php');
	require_once('../dbconnector.php');
	$id = $_POST['id'];
	
    $db = new DataBase;
	$db->makeConnection();
	
	$post = mysql_fetch_array($db->makeQuery('SELECT * FROM cmsarticles WHERE ID=' . $id));
	$db->closeConnection();
	
	echo '<h5>Title:</h5><input id="edit_post_title" name="post_title" type="text" value="' . $post['title'] . '">';
 	echo '<h5>Tagline:</h5>
		  <input id="edit_post_tagline" name="post_tagline" type="text" value="' .  $post['tagline'] . '">';
 	echo '<h5>Article Text:</h5>
		  <textarea id="edit_post_text" name="post_text" cols="" rows="">' . $post['thearticle'] . '</textarea>';
	echo '<h5>Catagories:</h5><small>Current Catagory:</small>
		  <select id="edit_post_catagories" name="Catagories"></select>';
?>



