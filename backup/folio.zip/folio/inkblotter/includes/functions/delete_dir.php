<?php
	require_once("../access.php");
	require_once("../settings.php");
	$settings = ServerSettings::getSettings();
	session_start();
	$dir = $settings['cmsdir'] . "/inkblotter/media/" . $_SESSION['currentdir'] . $_POST['id'];
	rrmdir($dir);
	
	//from php man rmdir
	function rrmdir($dir) { 
		if (is_dir($dir)) 
		{ 
			$objects = scandir($dir); 
			foreach ($objects as $object) 
			{ 
				if ($object != "." && $object != "..") { 
					if (filetype($dir."/".$object) == "dir") rrmdir($dir."/".$object); else unlink($dir."/".$object); 
				} 
			} 
			reset($objects); 
			rmdir($dir); 
	   } 
	 } 
?>