<html>
	<head>
		<?php include("includes/meta.php"); ?>
	</head>
	<body>
		<div id="container">
			<?php include("includes/header.php"); ?>
			<div id="content">			
			
				<div id="mainImage">
					<img src="css/images/indeximage.jpg" alt="Index Image" /> 
				</div>
				
				<div id="info">
				<p>Broadleaf Gun dogs is a small family run breeding/training establishment located in Wiltshire.
					We are Kennel club accredited breeders and aim to produce top quality, trainable gun dogs for the shooting field or as active loyal family pets.
					All our dogs are shot over regularly and work picking up 4 to 5 times per week throughout the shooting season.</p>
				<div id="contact">
					<h2>Contact Us:</h2>
					<span><b>Tel:</b> 01793 772979</span>
					<b>Mobiles:</b>
					<span><b>Julie - </b> 07740352837</span>
					<span><b>Lance - </b> 07865735555</span>
					<b>Emails:</b>
					<span><b>Julie - </b> julie@broadleafgundogs.co.uk</span><br />
					<span><b>Lance - </b> lance@broadleafgundogs.co.uk</span>
				</div>
				</div>
				
			</div>
			
			<div id="footer">
			</div>
			
		</div>	

	</body>
		
</html>
