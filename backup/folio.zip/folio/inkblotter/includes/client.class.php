<?php
require_once('dbconnector.php');
$inkblotter = new ClientClass;
$db = new DataBase;

class ClientClass {
	public $per_page = 2;
	
	//private functions
	private function makeQuery ($query)
	{
		global $db;
		return $db->makeQuery ($query);
	}
	
	private function returnArray($q, $arrayType)
	{
		static $query; 	  //keeping track of the current query
		static $querystr; //keeping track of the current SQL statement
		
		if (!isset($query) or $querystr != $q)
		{
			$querystr = $q;
			$query = $this->makeQuery($q);
		}
		
		return mysql_fetch_array($query, $arrayType);
	}
	
  //exscript will not cut tags in half.
	private function mb_substrws($text, $length) { 
		if((mb_strlen($text) > $length)) { 
			$whitespaceposition = mb_strpos($text, ' ', $length) - 1; 
			if($whitespaceposition > 0) { 
				$chars = count_chars(mb_substr($text, 0, ($whitespaceposition + 1)), 1); 
				if ($chars[ord('<')] > $chars[ord('>')]) { 
					$whitespaceposition = mb_strpos($text, ">", $whitespaceposition) - 1; 
				} 
				$text = mb_substr($text, 0, ($whitespaceposition + 1)); 
			} 
			// close unclosed html tags 
			if(preg_match_all("|(<([\w]+)[^>]*>)|", $text, $aBuffer)) { 
				if(!empty($aBuffer[1])) { 
					preg_match_all("|</([a-zA-Z]+)>|", $text, $aBuffer2); 
					if(count($aBuffer[2]) != count($aBuffer2[1])) { 
						$closing_tags = array_diff($aBuffer[2], $aBuffer2[1]); 
						$closing_tags = array_reverse($closing_tags); 
						foreach($closing_tags as $tag) { 
								$text .= '</'.$tag.'>'; 
						} 
					} 
				} 
			} 
	
		} 
		return $text; 
	}
  
  private function createExscript ($article)
  {
        $pos = explode("!exscript!", $article);

		$article = $pos[0];
        return $article;
  }
		
	//public functions
	public function getAllPosts ($paginate = false, $exscript = false, $ordertype = 'ID', $arrayType = MYSQL_ASSOC)
	{
		if ($paginate == true)
		{
			$current_page = 0;
			$start = $current_page * 2;
			$pp = 2;
			$q = "SELECT * FROM cmsarticles ORDER BY $ordertype DESC LIMIT $start, $pp";
		}
		else
		{
			$q = "SELECT * FROM cmsarticles ORDER BY $ordertype DESC";
		}

		return $this->returnArray($q, $arrayType);
	}
	
	public function getPosts($paginate = true, $start = 0, $count = 0, $exscript = 0, $ordertype = 'ID', $arrayType = MYSQL_ASSOC)
	{
		if ($paginate == true)
		{
			if (isset($_GET['page'])) 
			{
				$current_page = $_GET['page'];
				$start = ($current_page * $this->per_page) + $start;
			}
			
			$q = "SELECT * FROM cmsarticles ORDER BY $ordertype DESC LIMIT $start, $this->per_page";
		}
		else
		{
			$q = "SELECT * FROM cmsarticles ORDER BY $ordertype DESC LIMIT $start, $count";
		}
		$post = $this->returnArray($q, $arrayType);
		
		if ($exscript != 0)
		{
			if (strlen($post['thearticle']) >= $exscript)
			{	
				$post['thearticle'] = $this->createExscript($post['thearticle'], $exscript);
			}
		}
		
		return $post;
	}
	
	public function getPostById($id, $exscript = 0, $arrayType = MYSQL_ASSOC)
	{
		$q = "SELECT * FROM cmsarticles WHERE ID = $id";
		$post = $this->returnArray($q, $arrayType);
		
		if ($exscript != 0)
		{
		  if (strlen($post['thearticle']) >= $exscript)
		  {
			$post['thearticle'] = $this->createExscript($post['thearticle']);
		  }
		}
    
		return $post;
	}
	
	public function getLatestPost($exscript = 0, $ordertype = 'ID', $arrayType = MYSQL_ASSOC)
	{
		$q = "SELECT * FROM cmsarticles ORDER BY $ordertype DESC LIMIT 1";
		$post = $this->returnArray($q, $arrayType);
		if ($exscript != 0)
		{
			if (strlen($post['thearticle']) >= $exscript)
			{
				$post['thearticle'] = $this->createExscript($post['thearticle']);
			}
			
		}

		return $post;
	}
	
	public function getLatestPosts($num = 1, $ordertype = 'ID', $arrayType = MYSQL_ASSOC)
	{
		$q = "SELECT * FROM cmsarticles ORDER BY $ordertype DESC LIMIT $num";
		return $this->returnArray($q, $arrayType);
	}
	
	public function getCustomQuery($q, $arrayType = MYSQL_ASSOC)
	{
		return $this->returnArray($q, $arrayType);
	}
	
	public function pagination ($offset = 0)
	{
		$no_of_posts = mysql_num_rows($this->makeQuery("SELECT * FROM cmsarticles"));
		$no_of_posts -= $offset;
		$no_of_pages = ceil ($no_of_posts/$this->per_page);
		echo '<div id="ib-pagination"><ul>';
		for ($i = 0; $i < $no_of_pages; $i++)
		{
			echo '<li id="'.$i.'_page"><a href="#tabs-3">'.($i+1).'</a></li>';
		}
		echo '</ul></div>';
	}
}


?>