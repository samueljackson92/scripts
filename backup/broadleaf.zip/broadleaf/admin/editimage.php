<?php
	require("includes/access.php");
	require("includes/dbconnector.php");
	require("includes/util.php");
	require("includes/filemanager.php");
	DBConnector::makeConnection();
	
	if (isset($_GET['id']) and is_numeric($_GET['id']))
	{
		$id = (int) $_GET['id'];
		$row = mysql_fetch_array(DBConnector::makeQuery("SELECT * FROM gallery WHERE id=$id"));
	}
	elseif(isset($_POST['id']) and is_numeric($_POST['id']))
	{
		$id = (int) $_POST['id'];
	}
	else
	{
		header("Location: gallery.php");
		exit;
	}
	
	if (isset($_POST['title']))
	{
		$target_path = "media/gallery/";
		
		$fname = $_FILES['image']['name'];
		$ftempname = $_FILES['image']['tmp_name'];
		$title = $_POST['title'];
		$caption = $_POST['caption'];
		
		$title = Util::cleanInput($title);
		$caption = Util::cleanInput($caption);
		
		$row = mysql_fetch_array(DBConnector::makeQuery("SELECT * FROM gallery WHERE id=" . $_POST['id']));
		
		if ($fname != null)
		{
		
			while (true)
			{
				if (file_exists($target_path . $fname))
				{
					$i++;
					$ext = substr(basename($fname), -4);
					$fname = $fname . "(" . $i . ")" . $ext;
				}
				else
				{
					break;
				}
			}
			
			if(!$_FILES['image']['error'] == 0)
			{	
				$error = true;
			}
			
			if($_FILES['image']['size'] > 1500000)
			{
				$error = true;
			}
			
			
			if (!FileManager::uploadFile($fname, $ftempname, "media/gallery/"))
			{
				$error = true;
			}
			else
			{
				FileManager::removeFile("media/gallery/" . $row['filename']);
				DBConnector::makeQuery("UPDATE gallery SET image_name='$title', caption='$caption', filename='$fname' WHERE id=" . $_POST['id']);
				header("Location: gallery.php?success=0");
				exit;
			}
		}
		else
		{
			DBConnector::makeQuery("UPDATE gallery SET image_name='$title', caption='$caption' WHERE id=" . $_POST['id']);
			header("Location: gallery.php?success=0");
			exit;
		}
		

	}
?>

<html>
	<head>		
		<script type="text/javascript" src="js/jquery.js"></script>
		
		<link rel="stylesheet" type="text/css" href="css/admin-main.css">
		<link rel="stylesheet" type="text/css" href="css/admin-form.css">
		<link rel="stylesheet" type="text/css" href="css/admin-gallery.css">
		<title>Broadleaf Admin: Edit Image</title>
		<script type="text/javascript">
			$(document).ready(function ()
			{
				$("#editimage_submit").click(function()
				{
					var flag = false;
					$("#error_output").html("");
					
					if ($("#caption").val().length > 600)
					{
						flag = true;
						$("#error_output").append("<span>The caption may not be more than 600 characters long</span>");
					}
					
					if (!flag)
					{
						$("#editimage_form").submit()
					}
				});
				
				<?php if ($error)
				{
				?>
				$("#error_output").show();
				<?php
				}
				?>
			});
		</script>
	</head>
	<body>
		<div id="header"><h2>Gallery Editor</h2></div>
		<div id="menu">
			<ul>
				<li><a href="dogs.php?type=1">Studs &amp; Bitches</a></li>
				<li><a href="dogs.php?type=2">Dogs For Sale</a></li>
				<li><a href="dogs.php?type=3">Puppies</a></li>
				<li><a id="current" href="gallery.php">Gallery</a></li>
				<li><a href="info.php">Info</a></li>
				<li><a href="options.php">Settings</a></li>
				<li><a class="menu-right" href="logout.php">Log Out</a></li>
			</ul>
		</div>
		<div id="editor">
			<div id="err">
				<div id="error_output">
						<?php
							if ($error)
							{
						?>
							<span>Oops. Looks like we can't upload one of those images. Remember that images cannot be more than 1.5Mb in size. Images must also be in either jpeg, png or gif format.</span>
						<?php
							}
						?>
				</div>
			</div>
			<img src="media/gallery/<?php echo $row['filename']; ?>" alt="<?php echo html_entity_decode($row['image_name']); ?>" /><br /><br />
			<form id="editimage_form" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data" >
				<input name="id" type="hidden" value="<?php echo $id; ?>" />
				<input type="hidden" name="MAX_FILE_SIZE" value="1500000" />
				<label for="title">Title:</label>
				<input id="title" name="title" type="text" value="<?php if ($error) {echo html_entity_decode($title);} else { echo html_entity_decode($row['image_name']); } ?>" />
				<label for="caption">Caption:</label>
				<textarea id="caption" name="caption" ><?php if ($error) {echo html_entity_decode($caption); } else {echo html_entity_decode($row['caption']);} ?></textarea>
				<label for="image">Change Image:</label>
				<input type="file" name="image" />
				<input id="editimage_submit" class="button" name="button_submit" type="button" value="Edit Image"></input>
			</form>
		</div>
	</body>
</html>