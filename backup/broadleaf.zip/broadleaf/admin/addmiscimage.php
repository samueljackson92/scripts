<?php
	require("includes/access.php");
	require("includes/dbconnector.php");
	require("includes/filemanager.php");
	require("includes/util.php");
	
	
	if (isset($_FILES['gallery_images']))
	{
		DBConnector::makeConnection();
		
		$target_path = "media/misc/";
		
		for ($i = 0; $i < count($_FILES['gallery_images']['name']); $i++)
		{
			$fname = $_FILES['gallery_images']['name'][$i];
			
			$title = Util::cleanInput($title);
			$caption = Util::cleanInput($caption);
			
			$tmp_name = $_FILES['gallery_images']['tmp_name'][$i];
			
			while (file_exists($target_path . $fname))
			{
				$j++;
				$ext = substr(basename($fname), -4);
				$fname = $fname . "(" . $j . ")" . $ext;
			}
				
			if($_FILES['gallery_images']['error'][$i] != 0 and $_FILES['gallery_images']['error'][$i] != 4)
			{
				$error = true;
			}
			
			if($_FILES['gallery_images']['size'][$i] > 1500000)
			{
				$error = true;
			}
			
			if (!FileManager::uploadFile($fname, $tmp_name, $target_path))
			{
				$error = true;
			}
			else
			{
				DBConnector::makeQuery("INSERT INTO media (id, filename) VALUES ('NULL', '$fname')");
			}
		}

		if (!$error)
		{
			header("Location: miscmedia.php?success=0");
		}
	}		
?>

<html>
	<head>
		<script type="text/javascript" src="js/jquery.js" language="javascript"></script>
		<script src="js/jquery.MultiFile.js" type="text/javascript" language="javascript"></script>
		<link rel="stylesheet" type="text/css" href="css/admin-main.css">
		<link rel="stylesheet" type="text/css" href="css/admin-form.css">
		<link rel="stylesheet" type="text/css" href="css/admin-gallery.css">
		<style type="text/css">
			form textarea {height: 50px;}
		</style>
		<title>Broadleaf Admin: Add Image</title>
		<script type="text/javascript">
			$(document).ready(function ()
			{
				$("#addimages_submit").click(function()
				{
					var flag = false;
					$("#error_output").html("");

					if (!flag)
					{
						$("#addimages_form").submit()
					}
				});
				
				<?php if ($error)
				{
				?>
				$("#error_output").show();
				<?php
				}
				?>
			});
		</script>
	</head>
	<body>
		<div id="header"><h2>Add Dog</h2></div>
		<div id="menu">
			<ul>
				<li><a href="dogs.php?type=1">Studs &amp; Bitches</a></li>
				<li><a href="dogs.php?type=2">Dogs For Sale</a></li>
				<li><a href="dogs.php?type=3">Puppies</a></li>
				<li><a href="gallery.php">Gallery</a></li>
				<li><a id="current" href="miscmedia.php">Media</a></li>
				<li><a href="info.php">Info</a></li>
				<li><a href="options.php">Settings</a></li>
				<li><a class="menu-right" href="logout.php">Log Out</a></li>
			</ul>
		</div>
		<div id="wrapper">
			<div id="editor" class="add_gall_image">
				<div id="err">
					<div id="error_output">
						<?php
							if ($error)
							{
						?>
							<span>Oops. Looks like we can't upload one of those images. Remember that images cannot be more than 1.5Mb in size. Images must also be in either jpeg, png or gif format.</span>
						<?php
							}
						?>
					</div>
				</div>
				<form id="addimages_form" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
					<fieldset>
						<input type="hidden" name="MAX_FILE_SIZE" value="1500000" />
						<legend>Upload Images</legend>
						<input type="file" name="gallery_images[]" class="multi" accept="gif|png|jpg"/>
					</fieldset>
					<input id="addimages_submit" class="button" name="button_submit" type="button" value="Upload"></input>
				</form>
			</div>
		</div>
	</body>
</html>