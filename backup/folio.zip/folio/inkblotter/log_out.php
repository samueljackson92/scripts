<?php
	session_start();
	unset($_COOKIE['logged_in_cms']);
	unset($_SESSION['user']);
	unset($_SESSION['active']);
	
	if (!isset($_SESSION['loginfailed']))
	{
		session_destroy();
	}
	
	header("Location: login.php");
?>