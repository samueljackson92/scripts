<?php
	require_once('../access.php');
	require_once('../dbconnector.php');
	$db = new DataBase;
	$db->makeConnection();
	
	$password = makeSafe($_POST['password']);
	$user = makeSafe($_POST['username']);
	$access = makeSafe($_POST['access']);
	$email = makeSafe($_POST['email']);
	$nickname = makeSafe($_POST['nickname']);
	
	$time = strval(time());
	$salt = md5($time.$email);
	$password = sha1($salt . $password);
	
	$db->makeQuery("INSERT INTO `cmsdb`.`cmsusers` (`userid`, `username`, `password`, `level`, `email`, `user_nicename`, `unique_salt`) 
											VALUES (NULL, '$user', '$password', '$access', '$email', '$nickname', '$salt')");
	$db->closeConnection();
	
	function makeSafe($var)
	{
		return mysql_real_string(strip_tags($var));
	}
?>
