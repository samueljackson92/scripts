<?php 
class ServerSettings
{
	public $settings;
	
	public static function getSettings()
	{
		$dir = $_SERVER['SCRIPT_FILENAME'];
		$pieces = explode("/inkblotter", $dir);
		$dir = $pieces[0];
		
		//database variables
		$settings['dbuser'] = 'root';
		$settings['dbpassword'] = '';
		$settings['dbhost'] = 'localhost';
		$settings['dbname'] = 'cmsdb';
		
		$settings['cmsdir'] = $dir;
		$settings['siteaddr'] = $_SERVER['SERVER_NAME'] . "/folio/";
		
		return $settings;
	}
}
?>