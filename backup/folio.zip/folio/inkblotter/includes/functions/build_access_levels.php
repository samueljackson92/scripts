<?php
	require_once('../access.php');
	require_once('../dbconnector.php');
	$db = new DataBase;
	$db->makeConnection();
	
	if (isset($_POST['id']));
	{
		$id = $_POST['id'];
		$user = mysql_fetch_array($db->makeQuery("SELECT * FROM cmsusers WHERE userid='$id'"));
	}
	
	$result = $db->makeQuery('SELECT * FROM cmslevel');
	
	while ($row = mysql_fetch_array($result))
	{
		if ($row['levelindex'] == $user['level'])
		{
			echo '<option value="'.$row['levelindex'].'" selected="selected">'.$row['accesslevel'].'</option>';
		}
		else
		{
			echo '<option value="'.$row['levelindex'].'">'.$row['accesslevel'].'</option>';
		}
	}
	
	$db->closeConnection();
?>