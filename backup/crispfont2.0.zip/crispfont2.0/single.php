<?php get_header();?>
<style type="text/css">
	#content {width: 500px;}
</style>
	<div id="content">
	<?php if (have_posts()) : ?>
	<?php while (have_posts()) : the_post(); ?>
		<div class="post">
			<h2 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h2>
			<small class="date"><?php the_time('l, F j, Y');?></small><br />
			<small class="date"><?php the_category(',');;?></small>
			<div class="post-body">
				<?php the_content('Read More...');?>
				<?php comments_template();?>
			</div>
		</div>
		<a href="javascript:history.go(-1)" onMouseOver="self.status=document.referrer;return true"> &lt;&lt; Back</a>
	<?php endwhile; ?>
	<?php else : ?>
		<h2>Not Found</h2>
	<?php endif; ?>
	</div>
	<div class="push"></div>
</div>
<?php get_footer(); ?>