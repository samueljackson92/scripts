<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<?php
require_once('inkblotter/includes/client.class.php');
?>
<html>
	<head>
		<link rel="stylesheet" href="css/master.css" type="text/css" />
		<link rel="stylesheet" type="text/css" href="css/jquery.lightbox-0.5.css" media="screen" />
		
		<script src="js/jquery1-4-4.js" type="text/javascript"></script>
		<script type="text/javascript" src="js/jquery.lightbox-0.5.js"></script>
		<script type="text/javascript">
			$(document).ready(function(){
				$(".tab-content").hide();
				$("#tabs-1").show();
				$('.gallery a').lightBox();
				
				$("#tabs ul li").click(function(){
					$("#tabs ul li").removeClass("active");
					$(this).addClass("active");
					$(this).hide();
					$(this).fadeIn('fast');
					
					activeTab = $(this).find("a").attr("href");
					$("#tabs-container").slideUp(800, function ()
					{
							$(".tab-content").hide();
							$(this).show();
							$(activeTab).slideDown(800);
					});
					
					$("#ib-pagination ul").children("li").click(function()
					{
						id = $(this).attr("id");
						$("#projects").fadeOut(function()
						{
							$("#projects").html("");
							$("#ib-pagination").hide(); 
							ajax_script = "inkblotter/includes/client.paginate.php";
							$.post(ajax_script, {page_id: id}, function(data)
							{
								$("#projects").html(data);
								$("#projects").fadeIn();
								$("#ib-pagination").show(); 
							});
						});
					});
				});
			});
		</script>
		

	</head>
	<body>
		<div id="main">
			<div id="tabs">
				<ul>
					<li class="active"><a href="#tabs-1">Home</a></li>
					<li><a href="#tabs-2">About</a></li>
					<li><a href="#tabs-3">Blog</a></li>
				</ul>
			</div>
			<div id="tabs-container">
				<div id="tabs-1" class="tab-content">
					<div class="content">
						<div id="left">
							<div class="text">
								<h1>Samuel Jackson</h1>
								<h2>Student of Software Development</h2>
								<p>Hi, I'm Samuel Jackson, and I'm currently a UK software development student at New College, Swindon hoping to move onto a degree in software engineering this year.</p>
							</div>
						</div>
						<div id="right">
							<div id="profile-img">
								<img src="images/me.jpg" />
							</div>
							<div id="sub-right">
								<p><img src="images/mail.png" />&nbsp;<strong>twiicoup@gmail.com</strong></p>
							</div>
						</div>
					</div>
				</div>
				<div id="tabs-2" class="tab-content">
					<div class="content">
						<div class="text">
							<h1>About</h1>
							<h2>About Me</h2>
							<h4>Qualifications</h4>
							<p>I'm a BTEC Software Development student currently studying at the New College,  Swindon. So far as the time of this writing I've achieved every unit listed below to distinction level.</p>
							<p> Apart from that I've also been an A level business student (Grade B) and AS level computing student (Grade B). I'm currently a third year, hoping to go to university to study a software development masters degree</p>
							<h4>Skills</h4>
							<p>Over my three years of education and thorugh my oown efforts i have accquired knowledge of the following technologies:</p>
							<div id="skills">
								<div id="left-coll">
									<div class="lists">
										<h4>Programming Languages:</h4>
										<ul>
											<li>PHP</li>
											<li>VB.NET</li>
											<li>Lua</li>
											<li>C/C++</li>
											<li>JavaScript</li>
											<li>Java</li>
											<li>Python</li>
										</ul>
									</div>
									<div class="lists">
										<h4>Frameworks/Libraries:</h4>
										<ul>
											<li>JQuery</li>
											<li>JQuery UI</li>
											<li>Love 2D Game Engine</li>
											<li>SFML</li>
										</ul>
									</div>
								</div>
								<div id="right-coll">
									<div class="lists">
										<h4>Software Packages:</h4>
										<ul>
											<li>Dreamweaver CS3/4</li>
											<li>Photoshop CS3/4</li>
											<li>Eclipse + Aptana</li>
											<li>Netbeans</li>
											<li>Microsoft Visual Basic/C++ (Express)</li>
											<li>XAMPP/LAMPP</li>
										</ul>
									</div>
									<div class="lists">
										<h4>Other:</h4>
										<ul>
											<li>XHTML</li>
											<li>CSS</li>
											<li>MySQL</li>
											<li>PHPMyAdmin</li>
											<li>Mercurial (in combination with bitbucket)</li>
										</ul>
									</div>
								</div>
							</div>
							<h2>About The Site</h2>
							<p>Just in case your wondering this site was built using a combination of JQuery, PHP and MySQL. We're currently running on an apache webserver and the backend is handled by a CMS of my design written entirely in pure PHP and MySQL (still fairly "in the works").</p>
						</div>
					</div>
				</div>
				<div id="tabs-3" class="tab-content">
					<div class="content">
						<div class="text">
							<h1>Blog</h1>
							<p>Here you can find some different projects that i have worked on in the past (and present). Click on the images to get an expanded view. I also tend to put store a fair bit of my work on my bit bukcet account at <a href="https://bitbucket.org/cylax"><strong>bitbucket.org/cylax</strong></a>.</p>
						</div>
						<div id="projects">
									<?php
									while ($post = $inkblotter->getAllPosts(true, true))
									{
									?>
									<div id="post-<?php echo $post['ID']; ?>"  class="project">
											<h2 class="title"><?php echo $post['title'];?></h2>
											<small><i>Created: </i><?php echo $post ['posttime']; ?></small><br />
											<small><i>Last Edited: </i><?php echo $post ['edittime']; ?></small>
											<div class="intro"><?php echo $post['thearticle']; ?></div>
									</div>
									<?php
										}
									?>
						</div>
					<?php $inkblotter->pagination(); ?>
					</div>
				</div>
			</div>
			<div id="footer">
				<small>Copyright &copy; 2010 Samuel Jackson. All Rights Reserved.</small>
			</div>
		</div>
	</body>
</html>